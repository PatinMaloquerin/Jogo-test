import React, { useEffect, useState } from 'react';
import GameCanvas from './components/game/GameCanvas';
import { useAudio } from './lib/stores/useAudio';
import { useGameState } from './lib/stores/useGameState';
import { RaceSelectionScreen } from './components/ui/RaceSelectionScreen';
import '@fontsource/inter';

function ThemeToggle() {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <button onClick={toggleDarkMode} className="text-white bg-gray-800 hover:bg-gray-700 dark:bg-gray-200 dark:text-gray-900 dark:hover:bg-gray-300 p-2 rounded">
      {isDarkMode ? 'Light Mode' : 'Dark Mode'}
    </button>
  );
}


function App() {
  // Load audio assets
  const { setBackgroundMusic } = useAudio();
  const { isRaceSelectionOpen, selectRace } = useGameState();

  useEffect(() => {
    // Create and configure background music
    const bgMusic = new Audio('/sounds/background.mp3');
    bgMusic.loop = true;
    bgMusic.volume = 0.3;

    // Set up background music
    setBackgroundMusic(bgMusic);

    // Clean up on unmount
    return () => {
      bgMusic.pause();
    };
  }, [setBackgroundMusic]);

  const handleRaceSelection = (race: string, playerClass: string) => {
    selectRace(race, playerClass);
  };

  return (
    <div className="w-screen h-screen overflow-hidden dark:bg-gray-900">
      <div className="fixed top-4 right-4">
        <ThemeToggle />
      </div>
      <GameCanvas />
      
      {isRaceSelectionOpen && (
        <RaceSelectionScreen onSelectRace={handleRaceSelection} />
      )}
    </div>
  );
}

export default App;