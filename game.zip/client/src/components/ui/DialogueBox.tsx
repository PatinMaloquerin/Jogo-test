import React from 'react';
import { useQuestStore } from '../../lib/stores/useQuestStore';
import { useGameState } from '../../lib/stores/useGameState';
import { DialogueOption } from '../../lib/types/quest';
import { cn } from '../../lib/utils';

export const DialogueBox: React.FC = () => {
  const { activeDialogue, isDialogueOpen, selectDialogueOption, closeDialogue, checkOptionCondition } = useQuestStore();
  const { player } = useGameState();
  
  if (!isDialogueOpen || !activeDialogue) return null;
  
  const filteredOptions = activeDialogue.options.filter(option => 
    checkOptionCondition(option, player.stats.level)
  );
  
  const handleSelectOption = (option: DialogueOption) => {
    selectDialogueOption(option);
  };
  
  const handleClose = () => {
    closeDialogue();
  };
  
  return (
    <div className="fixed bottom-0 left-0 right-0 p-4 z-50">
      <div className="bg-black/80 border-2 border-yellow-400 rounded-lg p-4 mx-auto max-w-2xl text-white shadow-lg">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-yellow-400 font-bold text-xl">NPC</h3>
          <button 
            onClick={handleClose}
            className="text-gray-400 hover:text-white"
          >
            X
          </button>
        </div>
        
        <div className="mb-6 min-h-[80px]">
          <p>{activeDialogue.text}</p>
        </div>
        
        <div className="flex flex-col gap-2">
          {filteredOptions.map((option, index) => (
            <button
              key={index}
              onClick={() => handleSelectOption(option)}
              className={cn(
                "text-left px-4 py-2 rounded-md border border-yellow-400/50",
                "hover:bg-yellow-400/20 transition-colors",
                "focus:outline-none focus:ring-2 focus:ring-yellow-400/70"
              )}
            >
              {option.text}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};