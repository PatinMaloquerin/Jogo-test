import React from 'react';
import { Button } from '../button';
import { Tooltip } from '../tooltip';
import { usePlayer } from '../../../lib/stores/usePlayer';

export const StatPanel: React.FC = () => {
  const { player, increaseStat } = usePlayer();
  
  const stats = [
    {
      name: 'strength',
      abbreviation: 'STR',
      value: player.stats?.strength || 0,
      description: 'Increases physical attack damage'
    },
    {
      name: 'constitution',
      abbreviation: 'CON',
      value: player.stats?.constitution || 0,
      description: 'Increases maximum health'
    },
    {
      name: 'dexterity',
      abbreviation: 'DEX',
      value: player.stats?.dexterity || 0,
      description: 'Increases speed and stamina'
    },
    {
      name: 'willpower',
      abbreviation: 'WIL',
      value: player.stats?.willpower || 0,
      description: 'Increases magical attack damage'
    },
    {
      name: 'spirit',
      abbreviation: 'SPI',
      value: player.stats?.spirit || 0,
      description: 'Increases maximum mana'
    }
  ];
  
  return (
    <div className="stat-panel">
      <div className="mb-2 flex justify-between items-center">
        <span className="text-sm font-bold">Stats</span>
        <span className="bg-blue-500 text-white px-2 py-1 rounded-full text-xs">
          LVL {player.level} | TP {player.statPoints}
        </span>
      </div>
      
      <div className="text-xs text-gray-300 mb-2">
        EXP: {player.experience} / {player.experienceToNextLevel}
      </div>
      
      <div className="space-y-1">
        {stats.map((stat) => (
          <div key={stat.name} className="flex justify-between items-center">
            <Tooltip content={stat.description}>
              <div className="flex items-center">
                <span className="text-sm w-8">{stat.abbreviation}</span>
                <span className="text-xs ml-2">{stat.value}</span>
              </div>
            </Tooltip>
            
            {player.statPoints > 0 && (
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => increaseStat(stat.name as keyof typeof player.stats)}
              >
                +
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
