import React from 'react';

interface HealthBarProps {
  health: number;
  maxHealth: number;
  mana: number;
  maxMana: number;
  stamina: number;
  maxStamina: number;
}

export const HealthBar: React.FC<HealthBarProps> = ({
  health,
  maxHealth,
  mana,
  maxMana,
  stamina,
  maxStamina
}) => {
  // Calculate percentages
  const healthPercentage = Math.max(0, Math.min(100, (health / maxHealth) * 100));
  const manaPercentage = Math.max(0, Math.min(100, (mana / maxMana) * 100));
  const staminaPercentage = Math.max(0, Math.min(100, (stamina / maxStamina) * 100));
  
  return (
    <div className="status-bars-container bg-black bg-opacity-50 p-3 rounded-lg">
      {/* Health Bar */}
      <div className="resource-bar mb-2">
        <div className="flex justify-between mb-1">
          <span className="text-white text-xs">Health</span>
          <span className="text-white text-xs">{Math.floor(health)}/{maxHealth}</span>
        </div>
        <div className="health-bar">
          <div 
            className="health-bar-fill health-bar-health" 
            style={{ width: `${healthPercentage}%` }} 
          />
        </div>
      </div>
      
      {/* Mana Bar */}
      <div className="resource-bar mb-2">
        <div className="flex justify-between mb-1">
          <span className="text-white text-xs">Mana</span>
          <span className="text-white text-xs">{Math.floor(mana)}/{maxMana}</span>
        </div>
        <div className="health-bar">
          <div 
            className="health-bar-fill health-bar-mana" 
            style={{ width: `${manaPercentage}%` }} 
          />
        </div>
      </div>
      
      {/* Stamina Bar */}
      <div className="resource-bar">
        <div className="flex justify-between mb-1">
          <span className="text-white text-xs">Stamina</span>
          <span className="text-white text-xs">{Math.floor(stamina)}/{maxStamina}</span>
        </div>
        <div className="health-bar">
          <div 
            className="health-bar-fill health-bar-stamina" 
            style={{ width: `${staminaPercentage}%` }} 
          />
        </div>
      </div>
    </div>
  );
};
