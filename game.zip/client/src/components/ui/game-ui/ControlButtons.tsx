import React from 'react';
import { usePlayer } from '../../../lib/stores/usePlayer';
import { useRPGGame } from '../../../lib/stores/useRPGGame';
import { Button } from '../button';

export const ControlButtons: React.FC = () => {
  const { player, movePlayer, castFireball } = usePlayer();
  const { createFireballProjectile } = useRPGGame();
  
  // Handle D-pad button presses for movement
  const handleMove = (dx: number, dy: number) => {
    movePlayer(dx * 20, dy * 20);
  };
  
  // Handle attack button press
  const handleAttack = () => {
    // Check if player has enough stamina
    if (player.stamina >= 10) {
      // Trigger attack
      usePlayer.setState((state) => ({
        ...state,
        player: {
          ...state.player,
          isAttacking: true,
          lastAttackTime: Date.now(),
          stamina: state.player.stamina - 10
        }
      }));
      
      // Reset attack flag after cooldown
      setTimeout(() => {
        usePlayer.setState((state) => ({
          ...state,
          player: {
            ...state.player,
            isAttacking: false
          }
        }));
      }, player.attackCooldown || 500);
    }
  };
  
  // Handle fireball button press
  const handleFireball = () => {
    // Check if player has enough mana
    if (player.mana >= 15) {
      // Cast fireball in the current facing direction
      castFireball();
      
      // Create the projectile in the game
      createFireballProjectile(player);
    }
  };
  
  // Touch controls for mobile
  return (
    <div className="flex justify-between">
      {/* Movement D-Pad */}
      <div className="d-pad grid grid-cols-3 grid-rows-3">
        <div className="col-start-1 row-start-1"></div>
        <Button
          className="control-button col-start-2 row-start-1"
          onClick={() => handleMove(0, -1)}
        >
          ↑
        </Button>
        <div className="col-start-3 row-start-1"></div>
        
        <Button
          className="control-button col-start-1 row-start-2"
          onClick={() => handleMove(-1, 0)}
        >
          ←
        </Button>
        <div className="col-start-2 row-start-2"></div>
        <Button
          className="control-button col-start-3 row-start-2"
          onClick={() => handleMove(1, 0)}
        >
          →
        </Button>
        
        <div className="col-start-1 row-start-3"></div>
        <Button
          className="control-button col-start-2 row-start-3"
          onClick={() => handleMove(0, 1)}
        >
          ↓
        </Button>
        <div className="col-start-3 row-start-3"></div>
      </div>
      
      {/* Action Buttons */}
      <div className="attack-buttons">
        <Button
          className="control-button"
          onClick={handleAttack}
          disabled={player.stamina < 10}
        >
          <span title="Attack">⚔️</span>
        </Button>
        
        <Button
          className="control-button"
          onClick={handleFireball}
          disabled={player.mana < 15}
        >
          <span title="Fireball">🔥</span>
        </Button>
      </div>
    </div>
  );
};
