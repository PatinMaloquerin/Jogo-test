import React from 'react';
import { QuestStatus } from '../../lib/types';

interface QuestIndicatorProps {
  questStatus?: QuestStatus;
  position: {
    x: number;
    y: number;
  };
}

export const QuestIndicator: React.FC<QuestIndicatorProps> = ({ 
  questStatus, 
  position 
}) => {
  if (!questStatus) return null;
  
  // Define cores e símbolos com base no status da quest
  let color = '';
  let symbol = '';
  
  switch (questStatus) {
    case QuestStatus.AVAILABLE:
      color = 'text-yellow-400';
      symbol = '!';
      break;
    case QuestStatus.IN_PROGRESS:
      color = 'text-blue-400';
      symbol = '?';
      break;
    case QuestStatus.READY_TO_TURN_IN:
      color = 'text-blue-400';
      symbol = '?';
      break;
    case QuestStatus.COMPLETED:
      color = 'text-green-400';
      symbol = '✓';
      break;
    default:
      return null;
  }
  
  return (
    <div
      className={`absolute ${color} font-bold text-xl`}
      style={{
        top: position.y - 35,
        left: position.x + 10,
        textShadow: '1px 1px 2px black'
      }}
    >
      {symbol}
    </div>
  );
};