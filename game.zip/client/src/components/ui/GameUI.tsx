import React, { useCallback, useState } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { Joystick } from 'react-joystick-component';
import { IJoystickUpdateEvent } from 'react-joystick-component/build/lib/Joystick';
import { Maximize2, Minimize2 } from 'lucide-react';
import { ChatBox } from './ChatBox';

interface GameUIProps {
  onAttack: () => void;
  onMagicAttack: () => void;
  onUpgradeMenu: () => void;
  onTransform?: () => void;
}

const GameUI: React.FC<GameUIProps> = ({ onAttack, onMagicAttack, onUpgradeMenu, onTransform }) => {
  const { player, getCanvasDimensions } = useGameState();
  const { width, height } = getCanvasDimensions();
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const {
    health,
    maxHealth,
    ki, // Renomeado de mana para ki
    maxKi, // Renomeado de maxMana para maxKi
    stamina,
    level,
    experiencePoints,
    statPoints
  } = player.stats;
  
  // Calculate bar percentages
  const healthPercentage = (health / maxHealth) * 100;
  const kiPercentage = (ki / maxKi) * 75;  // Renomeado de manaPercentage para kiPercentage
  const staminaPercentage = (stamina / 100) * 100;
  const expNeededForLevel = 100 * level;
  
  // Joystick handlers
  const handleJoystickMove = useCallback((event: IJoystickUpdateEvent) => {
    const { x, y } = event;
    const controls = useGameState.getState().controls;
    
    // Use threshold to determine when to trigger movement
    const threshold = 0.5;
    
    // Update directional controls based on joystick position (com valores seguros)
    // Invertendo o eixo Y (para cima é positivo, para baixo é negativo)
    useGameState.getState().setControls({
      ...controls,
      up: (y ?? 0) > threshold,     // Invertido: para cima quando y é positivo
      down: (y ?? 0) < -threshold,  // Invertido: para baixo quando y é negativo
      left: (x ?? 0) < -threshold,
      right: (x ?? 0) > threshold
    });
  }, []);
  
  const handleJoystickStop = useCallback(() => {
    const controls = useGameState.getState().controls;
    
    // Reset all directional controls when joystick is released
    useGameState.getState().setControls({
      ...controls,
      up: false,
      down: false,
      left: false,
      right: false
    });
  }, []);
  
  // Função para alternar o modo de tela cheia
  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
        .then(() => {
          setIsFullscreen(true);
        })
        .catch(err => {
          console.error(`Erro ao entrar em modo de tela cheia: ${err.message}`);
        });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
          .then(() => {
            setIsFullscreen(false);
          })
          .catch(err => {
            console.error(`Erro ao sair do modo de tela cheia: ${err.message}`);
          });
      }
    }
  }, []);
  
  return (
    <>
      {/* Botão de tela cheia removido daqui e movido para o minimapa */}
      
      {/* Stats UI (top left) - Barras de vida, KI */}
      <div className="absolute top-2 left-2 bg-gray-800 bg-opacity-70 p-2 rounded text-white text-sm">
        {/* Barra de vida sem texto adicional */}
        <div className="mb-1">
          <div className="flex justify-between text-xs text-white mb-1" style={{ width: '250px' }}>
          </div>
          <div className="w-full h-5 bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-green-500"
              style={{ width: `${healthPercentage}%` }}
            ></div>
          </div>
        </div>
        
        {/* Barra de KI sem texto adicional */}
        <div className="mb-1">
          <div className="flex justify-between text-xs text-white mb-1" style={{ width: '125px' }}>
          </div>
          <div className="w-full h-3 bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500"
              style={{ width: `${kiPercentage}%` }}
            ></div>
          </div>
        </div>
      </div>
      

      
      {/* Movement controls (bottom left) - Joystick */}
      <div className="absolute bottom-10 left-10 flex justify-center items-center">
        <div className="bg-gray-800 bg-opacity-70 rounded-full p-2">
          <Joystick 
            size={125}
            baseColor="rgba(75, 85, 99, 0.8)"
            stickColor="rgba(55, 65, 81, 1)"
            move={handleJoystickMove}
            stop={handleJoystickStop}
          />
        </div>
      </div>
      
      {/* Attack button (bottom right, positioned as a jump button) */}
      <div className="absolute bottom-40 right-40">
        <button
          className="bg-red-600 hover:bg-red-500 text-white w-20 h-20 rounded-lg opacity-80 hover:opacity-100 flex items-center justify-center"
          onClick={onAttack}
        >
          🗡️
        </button>
      </div>
      
      {/* Other action buttons (bottom right) */}
      <div className="absolute bottom-4 right-4 flex space-x-4">
        <button
          className="bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg opacity-80 hover:opacity-100"
          onClick={() => {
            // Recarregar KI
            const player = useGameState.getState().player;
            useGameState.getState().updatePlayer({
              ...player,
              stats: {
                ...player.stats,
                ki: player.stats.maxKi
              }
            });
          }}
        >
          Carregar KI
        </button>
        <button
          className="bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg opacity-80 hover:opacity-100"
          onClick={onUpgradeMenu}
        >
          Status
        </button>
        <button
          className="bg-yellow-600 hover:bg-yellow-500 text-white px-4 py-2 rounded-lg opacity-80 hover:opacity-100"
          onClick={onTransform}
          disabled={player.stats.transformationPoints < player.stats.transformationCost}
          title={`Transformar (Custo: ${player.stats.transformationCost} TP)`}
        >
          Transformar
        </button>
      </div>
      
      {/* Chat Box Component */}
      <ChatBox />

    </>
  );
};

export default GameUI;
