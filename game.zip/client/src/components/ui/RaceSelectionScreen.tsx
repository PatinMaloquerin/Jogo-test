import React, { useState } from "react";
import { useGameState } from "../../lib/stores/useGameState";

interface RaceSelectionScreenProps {
  onSelectRace: (race: string, playerClass: string) => void;
}

export function RaceSelectionScreen({ onSelectRace }: RaceSelectionScreenProps) {
  const [playerName, setPlayerName] = useState("");
  const [nameError, setNameError] = useState(false);
  const [step, setStep] = useState(1); // 1 = nome, 2 = escolha de raça, 3 = escolha de classe
  const [selectedRace, setSelectedRace] = useState("");
  
  const races = [
    {
      id: "human",
      name: "Humano",
      description: "Equilibrado e adaptável",
      stats: "CON 5 - STR 5 - DEX 5 - WIL 5 - SPI 5",
      color: "#FFD3BD",
      borderColor: "#FF9A76"
    },
    {
      id: "saiyan",
      name: "Saiyajin",
      description: "Alto poder ofensivo",
      stats: "CON 6 - STR 8 - DEX 4 - WIL 3 - SPI 4",
      color: "#FFB142",
      borderColor: "#FF8C00"
    },
    {
      id: "arcosian",
      name: "Arcosiano",
      description: "Resistente e ágil",
      stats: "CON 7 - STR 3 - DEX 7 - WIL 4 - SPI 4",
      color: "#9DB4FF",
      borderColor: "#6A89FF"
    },
    {
      id: "namekian",
      name: "Namekuseijin",
      description: "Força e poder espiritual",
      stats: "CON 6 - STR 6 - DEX 4 - WIL 3 - SPI 6",
      color: "#7CFC00",
      borderColor: "#4CAF50"
    }
  ];
  
  const classes = [
    {
      id: "warrior",
      name: "Guerreiro",
      description: "Especialista em combate físico e mágico",
      bonus: "+3 STR, +3 WIL",
      color: "#FF5252",
      borderColor: "#D32F2F"
    },
    {
      id: "spiritualist",
      name: "Espiritualista",
      description: "Grande foco em poder espiritual",
      bonus: "+3 SPI, +1 CON, +1 STR, +1 DEX",
      color: "#7986CB",
      borderColor: "#3F51B5"
    },
    {
      id: "tanker",
      name: "Tanker",
      description: "Alta resistência e agilidade",
      bonus: "+3 CON, +3 DEX",
      color: "#66BB6A",
      borderColor: "#388E3C"
    }
  ];

  const handleSubmitName = (e: React.FormEvent) => {
    e.preventDefault();
    if (playerName.trim().length < 3 | playerName.trim().length > 15) {
      setNameError(true);
      return;
    }
    setNameError(false);
    setStep(2);
  };
  
  const handleSelectRace = (race: string) => {
    setSelectedRace(race);
    setStep(3);
  };

  const handleSelectClass = (playerClass: string) => {
    // Atualizar o nome do jogador e depois chamar a função de seleção de raça e classe
    const gameState = useGameState.getState();
    const currentPlayer = gameState.player;
    
    useGameState.setState({ 
      playerName: playerName,
      player: {
        ...currentPlayer,
        name: playerName
      }
    });
    
    onSelectRace(selectedRace, playerClass);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50">
      <div className="bg-slate-800 p-4 rounded-lg shadow-lg w-[90%] max-w-xl max-h-[90vh] overflow-y-auto text-white">
        {step === 1 ? (
          // Tela para inserir o nome
          <div className="flex flex-col items-center">
            <h2 className="text-xl font-bold text-center mb-4">Digite seu Nome</h2>
            
            <form onSubmit={handleSubmitName} className="w-full max-w-md">
              <div className="mb-4">
                <input
                  type="text"
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  className={`w-full p-3 bg-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 ${nameError ? 'border-2 border-red-500' : ''}`}
                  placeholder="Nome do seu personagem"
                  autoFocus
                />
                {nameError && (
                  <p className="text-red-500 text-sm mt-1">O nome precisa ter pelo menos 3-15 caracteres</p>
                )}
              </div>
              
              <button 
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors"
              >
                Continuar
              </button>
            </form>
          </div>
        ) : step === 2 ? (
          // Tela de seleção de raça (compacta)
          <>
            <h2 className="text-xl font-bold text-center mb-4">Escolha sua Raça, {playerName}</h2>
            
            <div className="grid grid-cols-2 gap-3 mb-3">
              {races.map((race) => (
                <div 
                  key={race.id}
                  className="border-2 rounded-lg p-3 cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1"
                  onClick={() => handleSelectRace(race.id)}
                  style={{ borderColor: race.borderColor }}
                >
                  <div 
                    className="w-12 h-12 mx-auto rounded-full shadow-lg mb-2"
                    style={{ backgroundColor: race.color }}
                  ></div>
                  <h3 className="text-md font-bold mb-1 text-center">{race.name}</h3>
                  <p className="text-gray-300 text-xs text-center">{race.description}</p>
                  <p className="text-yellow-300 text-xs text-center mt-1 font-mono">{race.stats}</p>
                </div>
              ))}
            </div>
          </>
        ) : (
          // Tela de seleção de classe
          <>
            <h2 className="text-xl font-bold text-center mb-4">Escolha sua Classe</h2>
            
            <div className="grid grid-cols-1 gap-3 mb-3">
              {classes.map((classItem) => (
                <div 
                  key={classItem.id}
                  className="border-2 rounded-lg p-3 cursor-pointer hover:shadow-xl transition-all hover:-translate-y-1"
                  onClick={() => handleSelectClass(classItem.id)}
                  style={{ borderColor: classItem.borderColor }}
                >
                  <div className="flex items-center">
                    <div 
                      className="w-12 h-12 rounded-full shadow-lg"
                      style={{ backgroundColor: classItem.color }}
                    ></div>
                    <div className="ml-3">
                      <h3 className="text-md font-bold">{classItem.name}</h3>
                      <p className="text-gray-300 text-sm">{classItem.description}</p>
                      <p className="text-yellow-300 text-xs font-mono mt-1">{classItem.bonus}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}