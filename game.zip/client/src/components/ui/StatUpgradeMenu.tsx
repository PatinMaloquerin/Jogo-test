import React, { useState } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { CharacterStats } from '@/lib/types';

// Tipo para as diferentes abas do menu
type MenuTab = 'stats' | 'techniques';

const StatUpgradeMenu: React.FC = () => {
  const { player, upgradeStat, toggleUpgradeMenu, selectedRace } = useGameState();
  const { stats } = player;
  const [activeTab, setActiveTab] = useState<MenuTab>('stats');
  
  // Estado para controle do multiplicador de pontos (UC)
  const [uc, setUc] = useState(1);
  
  // Função para fazer upgrade múltiplo de atributos
  const upgradeMultipleStats = (stat: keyof CharacterStats, count: number) => {
    const gameState = useGameState.getState();
    const { player } = gameState;
    
    // Obter o valor base do atributo
    const baseValue = getBaseValue(stat);
    const currentLevel = player.stats[stat] as number;
    let remainingTP = player.stats.transformationPoints;
    let updatedStat = currentLevel;
    
    // Vamos calcular quanto TP seria gasto e quantos pontos seriam ganhos
    for (let i = 0; i < count; i++) {
      const upgradeCost = 15 + updatedStat * uc;
      
      // Verificar se há TP suficiente
      if (remainingTP >= upgradeCost) {
        remainingTP -= upgradeCost;
        updatedStat += 1;
      } else {
        // Não há mais TP suficiente, interromper
        break;
      }
    }
    
    // Aplicar as mudanças de uma vez, se houver alguma
    if (updatedStat > currentLevel) {
      // Criar um objeto com as atualizações
      const updatedPlayer = {
        ...player,
        stats: {
          ...player.stats,
          [stat]: updatedStat,
          transformationPoints: remainingTP
        }
      };
      
      // Atualizar o jogador usando upgradeStat diretamente para cada ponto
      // Isso garante que todos os cálculos e efeitos relacionados sejam aplicados
      const pointsToAdd = updatedStat - currentLevel;
      for (let i = 0; i < pointsToAdd; i++) {
        gameState.upgradeStat(stat, true);
      }
    }
  };
  
  // Custo base e adicional para compras de status
  const baseCost = 15;
  const [additionalCost, setAdditionalCost] = useState(0); // Aumenta 1 a cada upgrade
  
  // Custo para aumento de atributos
  const UpgradedCost = (baseCost + additionalCost) * uc;
  
  // Obter formatação de texto da raça
  const raceDisplayName = {
    'human': 'Humano',
    'saiyan': 'Saiyajin',
    'arcosian': 'Arcosiano',
    'namekian': 'Namekuseijin'
  }[selectedRace || 'human'] || 'Desconhecido';
  
  // Nível de transformação para exibição
  const transformationLevelText = stats.transformationLevel === 0 
    ? 'Base' 
    : `Forma ${stats.transformationLevel}`;
  
  // Get canvas dimensions to center the menu
  const { width, height } = useGameState.getState().getCanvasDimensions();
  
  // Obtém o valor base do atributo de acordo com a raça
  const getBaseValue = (stat: keyof typeof stats): number => {
    switch (selectedRace) {
      case 'human':
        break;
      case 'saiyan':
        break;
      case 'arcosian':
        break;
      case 'namekian':
        break;
    }
    return 1; // Valor padrão
  };
  
  // Manipulador para upgrade de atributos com TP
  const handleUpgradeWithTP = (stat: keyof typeof stats) => {
    const cost = UpgradedCost;
    
    if (stats.transformationPoints >= cost) {
      // Se houver TP suficiente, remove o custo do TP e adiciona UC para o status
      const gameState = useGameState.getState();
      const { player } = gameState;
      
      // Criar um objeto com as atualizações
      const updatedPlayer = {
        ...player,
        stats: {
          ...player.stats,
          [stat]: (player.stats[stat] as number) + uc,
          transformationPoints: player.stats.transformationPoints - cost // Mantemos a propriedade original no objeto
        }
      };
      
      // Atualizar o jogador
      gameState.updatePlayer(updatedPlayer);
      
      // Aumentar o additionalCost em 1 a cada vez que um atributo é aumentado
      setAdditionalCost(additionalCost + 1);
    }
  };

  // Aumentar o multiplicador UC
  const increaseUC = () => {
    if (uc < 25) { // Limitar a 25 para evitar gastos acidentais extremos
      setUc(uc + 1);
    }
  };
  
  // Diminuir o multiplicador UC
  const decreaseUC = () => {
    if (uc > 1) {
      setUc(uc - 1);
    }
  };
  
  return (
    <div
      className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50"
      style={{ width, height, zIndex: 50 }}
    >
      <div className="bg-gray-800 rounded-lg shadow-lg p-4 max-w-[90%] w-80 max-h-[90vh] overflow-y-auto text-white">
        <div className="flex justify-between items-center mb-2">
          <h2 className="text-lg font-bold">Informações</h2>
          <button
            className="text-gray-400 hover:text-white"
            onClick={toggleUpgradeMenu}
          >
            ✕
          </button>
        </div>
        
        {/* Menu tabs */}
        <div className="flex mb-2 border-b border-gray-700">
          <button
            className={`py-1 px-3 text-sm ${activeTab === 'stats' ? 'border-b-2 border-blue-500 text-blue-400' : 'text-gray-400'}`}
            onClick={() => setActiveTab('stats')}
          >
            Menu
          </button>
          <button
            className={`py-1 px-3 text-sm ${activeTab === 'techniques' ? 'border-b-2 border-blue-500 text-blue-400' : 'text-gray-400'}`}
            onClick={() => setActiveTab('techniques')}
          >
            Técnicas
          </button>
        </div>
        
        {activeTab === 'stats' && (
          <>
            {/* Informações do personagem - grid de 2 colunas */}
            <div className="bg-gray-700 p-2 rounded mb-2">
              <div className="grid grid-cols-1 gap-x-1 text-xs">
                <div className="flex">
                  <span className="w-12 text-white-400">Nível:</span> <span className="text-gray-400 text-xs font-bold"> {stats.level}</span>
                </div>
                <div className="flex">
                  <span className="w-12 text-white-400">TP:</span> <span className="text-gray-400 text-xs font-bold">{stats.transformationPoints}</span>
                </div>
                <div className="flex">
                  <span className="w-12 text-white-400">Raça:</span> <span className="text-gray-400 text-xs font-bold"> {raceDisplayName}</span>
                </div>
                <div className="flex">
                  <span className="w-12 text-white-400">Classe:</span> <span className="text-gray-400 text-xs font-bold"> {
                    player.selectedClass === 'warrior' ? 'Guerreiro' :
                    player.selectedClass === 'spiritualist' ? 'Espiritualista' :
                    player.selectedClass === 'tanker' ? 'Tanker' : 'Desconhecida'
                  }
                  </span>
                </div>
                <div className="flex">
                  <span className="w-12 text-white-400">Forma:</span> <span className="text-gray-400 text-xs font-bold"> {transformationLevelText}</span>
                </div>
                <div className="flex">
                  <span className="w-12 font-medium text-white-400 text-sm">Atributos:</span>
                </div>
             </div>
            
              {/* Strength */}
              <div className="flex items-center bg-gray-700 p-1 rounded">
                <button
                  className={`px-2 py-0 mr-2 rounded text-sm ${stats.transformationPoints >= UpgradedCost ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-gray-600 cursor-not-allowed'}`}
                  onClick={() => handleUpgradeWithTP('strength')}
                  disabled={stats.transformationPoints < UpgradedCost}
                >
                  +
                </button>
                <div className="font-medium text-sm">STR <span className={`${stats.transformationPoints >= UpgradedCost ? 'text-yellow-400 text-xs' : 'text-gray-400 text-xs'}`}>{stats.strength}</span></div>
              </div>
              
              {/* Constitution */}
              <div className="flex items-center bg-gray-700 p-1 rounded">
                <button
                  className={`px-2 py-0 mr-2 rounded text-sm ${stats.transformationPoints >= UpgradedCost ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-gray-600 cursor-not-allowed'}`}
                  onClick={() => handleUpgradeWithTP('constitution')}
                  disabled={stats.transformationPoints < UpgradedCost}
                >
                  +
                </button>
                <div className="font-medium text-sm">CON <span className={`${stats.transformationPoints >= UpgradedCost ? 'text-yellow-400 text-xs' : 'text-gray-400 text-xs'}`}>{stats.constitution}</span></div>
              </div>
              
              {/* Dexterity */}
              <div className="flex items-center bg-gray-700 p-1 rounded">
                <button
                  className={`px-2 py-0 mr-2 rounded text-sm ${stats.transformationPoints >= UpgradedCost ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-gray-600 cursor-not-allowed'}`}
                  onClick={() => handleUpgradeWithTP('dexterity')}
                  disabled={stats.transformationPoints < UpgradedCost}
                >
                  +
                </button>
                <div className="font-medium text-sm">DEX <span className={`${stats.transformationPoints >= UpgradedCost ? 'text-yellow-400 text-xs' : 'text-gray-400 text-xs'}`}>{stats.dexterity}</span></div>
              </div>
              
              {/* Willpower */}
              <div className="flex items-center bg-gray-700 p-1 rounded">
                <button
                  className={`px-2 py-0 mr-2 rounded text-sm ${stats.transformationPoints >= UpgradedCost ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-gray-600 cursor-not-allowed'}`}
                  onClick={() => handleUpgradeWithTP('willpower')}
                  disabled={stats.transformationPoints < UpgradedCost}
                >
                  +
                </button>
                <div className="font-medium text-sm">WIL <span className={`${stats.transformationPoints >= UpgradedCost ? 'text-yellow-400 text-xs' : 'text-gray-400 text-xs'}`}>{stats.willpower}</span></div>
              </div>
              
              {/* Spirit */}
              <div className="flex items-center bg-gray-700 p-1 rounded">
                <button
                  className={`px-2 py-0 mr-2 rounded text-sm ${stats.transformationPoints >= UpgradedCost ? 'bg-yellow-600 hover:bg-yellow-500' : 'bg-gray-600 cursor-not-allowed'}`}
                  onClick={() => handleUpgradeWithTP('spirit')}
                  disabled={stats.transformationPoints < UpgradedCost}
                >
                  +
                </button>
                <div className="font-medium text-sm">SPI <span className={`${stats.transformationPoints >= UpgradedCost ? 'text-yellow-400 text-xs' : 'text-gray-400 text-xs'}`}>{stats.spirit}</span></div>
              </div>
              
              {/* Multiplicador UC */}
              <div className="flex items-center justify-between bg-gray-600 p-1 rounded mt-2 text-sm">
                <div className="flex items-center">
                  <div className="mr-1 font-medium text-sm">UC</div>
                  <div className="text-gray-400 text-xs">
                    {UpgradedCost} TP
                  </div>
                </div>
                <div className="flex items-center">
                  <button
                    className="px-1 py-0 rounded bg-gray-500 hover:bg-gray-400 mr-1 text-xs"
                    onClick={decreaseUC}
                    disabled={uc <= 1}
                  >
                    -
                  </button>
                  <div className="mx-1 font-bold text-white text-xs">
                    ×{uc}
                  </div>
                  <button
                    className="px-1 py-0 rounded bg-gray-500 hover:bg-gray-400 ml-1 text-xs"
                    onClick={increaseUC}
                    disabled={uc >= 10}
                  >
                    +
                  </button>
                </div>
              </div>
            </div>
          </>
        )}
        
        {activeTab === 'techniques' && (
          <div className="min-h-36">
            <p className="text-center text-gray-400 mb-2 text-xs">Técnicas desbloqueadas:</p>
            
            {/* Lista de técnicas (a ser implementado) */}
            <div className="bg-gray-700 p-2 rounded mb-2">
              <div className="text-center text-yellow-500 text-xs">
                Em breve! Técnicas serão desbloqueadas conforme você progredir.
              </div>
            </div>
            
            <div className="bg-gray-700 p-2 rounded mb-2">
              <div className="text-xs">
                <p>- Superform: Transformação que aumenta todos seus atributos.</p>
                <p>- KI Blast: ataque básico de KI (desbloqueado)</p>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default StatUpgradeMenu;
