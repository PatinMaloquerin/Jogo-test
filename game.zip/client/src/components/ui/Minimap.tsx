import React, { useRef, useEffect, useState, useCallback } from 'react';
import { useGameState } from '@/lib/stores/useGameState';
import { Character, CharacterType, Position } from '@/lib/types';
import { Maximize2, Minimize2 } from 'lucide-react';

interface MinimapProps {
  size: number;
}

export const Minimap: React.FC<MinimapProps> = ({ size }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const {
    player,
    enemies,
    npcs,
    getCanvasDimensions
  } = useGameState();
  
  // Função para alternar o modo de tela cheia
  const toggleFullscreen = useCallback(() => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
        .then(() => {
          setIsFullscreen(true);
        })
        .catch(err => {
          console.error(`Erro ao entrar em modo de tela cheia: ${err.message}`);
        });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen()
          .then(() => {
            setIsFullscreen(false);
          })
          .catch(err => {
            console.error(`Erro ao sair do modo de tela cheia: ${err.message}`);
          });
      }
    }
  }, []);

  // Desenha o minimapa
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Limpa o canvas
    ctx.clearRect(0, 0, size, size);

    // Desenha o fundo (sem transparência)
    ctx.fillStyle = '#333333'; // Cor sólida escura para o fundo
    ctx.fillRect(0, 0, size, size);

    // Obtém as dimensões do canvas principal
    const { width: gameWidth, height: gameHeight } = getCanvasDimensions();

    // Posição do jogador (centro da visão)
    const playerCenterX = size / 2;
    const playerCenterY = size / 2;

    // Coordenadas X e Y do jogador (valores reais no mundo)
    const playerX = Math.round(player.position.x);
    const playerY = Math.round(player.position.y);
    
    // Fator de escala para ajustar a distância no minimapa (valores maiores aproximam os pontos)
    const scaleFactor = 3.0;

    // Desenha grade de fundo (opcional)
    ctx.strokeStyle = '#444444';
    ctx.lineWidth = 0.5;
    // Tamanho da grade, ajustado com o fator de escala
    const gridSize = 20 / scaleFactor;
    
    // Ajuste da grade baseado na posição do jogador
    const offsetX = ((playerX / scaleFactor) % gridSize);
    const offsetY = ((playerY / scaleFactor) % gridSize);
    
    // Desenhar linhas horizontais
    for (let y = -offsetY; y < size; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(size, y);
      ctx.stroke();
    }
    
    // Desenhar linhas verticais
    for (let x = -offsetX; x < size; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, size);
      ctx.stroke();
    }

    // Função para desenhar uma entidade no minimapa, considerando o jogador como centro
    const drawEntity = (position: Position, color: string, entitySize: number = 4) => {
      // Calcula a posição relativa ao jogador
      const relativeX = (position.x - player.position.x) / scaleFactor;
      const relativeY = (position.y - player.position.y) / scaleFactor;
      
      // Posição na tela do minimapa (com jogador centralizado)
      const screenX = playerCenterX + relativeX;
      const screenY = playerCenterY + relativeY;
      
      // Verifica se a entidade está dentro dos limites do minimapa
      if (screenX >= 0 && screenX <= size && screenY >= 0 && screenY <= size) {
        ctx.fillStyle = color;
        ctx.beginPath();
        ctx.arc(screenX, screenY, entitySize, 0, Math.PI * 2);
        ctx.fill();
      }
    };

    // Desenha os inimigos (pontos verdes para passivos, vermelhos para agressivos)
    enemies.forEach(enemy => {
      const color = enemy.type === CharacterType.PASSIVE_ENEMY 
        ? 'green' 
        : 'red';
      drawEntity(enemy.position, color);
    });

    // Desenha os NPCs (pontos roxos)
    npcs.forEach(npc => {
      drawEntity(npc.position, 'purple');
    });

    // Desenha o jogador (ponto branco) no centro
    ctx.fillStyle = 'white';
    ctx.beginPath();
    ctx.arc(playerCenterX, playerCenterY, 6, 0, Math.PI * 2);
    ctx.fill();

    // Desenha a borda
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, 0, size, size);

    // Adiciona as coordenadas X e Y ao lado do minimapa
    ctx.fillStyle = 'white';
    ctx.font = '12px Arial';
    ctx.fillText(`X: ${playerX}`, 5, 14);
    ctx.fillText(`Y: ${playerY}`, 5, 30);

  }, [player, enemies, npcs, size, getCanvasDimensions]);

  // Obtém o valor de stamina do jogador
  const { stamina, maxStamina } = player.stats;
  const staminaPercentage = (stamina / maxStamina) * 100;
  
  return (
    <div 
      style={{
        position: 'absolute', // Posiciona o minimapa no canto superior direito da tela
        top: '10px',
        right: '10px',
        zIndex: 10,
      }}
    >
      <div
        style={{
          width: `${size}px`,
          height: `${size}px`,
          border: '2px solid white',
          borderRadius: '3px',
          overflow: 'hidden',
          backgroundColor: '#333333' // Garante que não haja transparência
        }}
      >
        <canvas 
          ref={canvasRef}
          width={size}
          height={size}
        />
        
        {/* Botão de tela cheia no canto superior direito do minimapa */}
        <button
          className="absolute top-1 right-1 bg-gray-800 hover:bg-gray-700 text-white p-1 rounded-full opacity-80 hover:opacity-100 transition-opacity"
          onClick={toggleFullscreen}
          title={isFullscreen ? "Sair da tela cheia" : "Entrar em tela cheia"}
          style={{ 
            zIndex: 20,
            width: '28px',
            height: '28px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
        >
          {isFullscreen ? <Minimize2 size={16} /> : <Maximize2 size={16} />}
        </button>
      </div>
      
      {/* Barra de energia vertical à direita do minimapa */}
      <div 
        className="bg-gray-700 rounded-md overflow-hidden relative"
        style={{
          width: '15px',
          height: '120px',
          position: 'absolute',
          top: '0',
          right: '-25px',
          border: '1px solid rgba(255,255,255,0.3)',
        }}
      >
        <div
          className="bg-green-500 w-full absolute bottom-0"
          style={{ 
            height: `${staminaPercentage}%`,
            width: '100%',
            transition: 'height 0.2s ease'
          }}
        ></div>
        <div 
          className="absolute top-0 left-0 w-full"
          style={{
            transform: 'rotate(-90deg) translate(-120px, -2px)',
            transformOrigin: 'bottom left',
            fontSize: '8px',
            color: 'white',
            textShadow: '0 0 2px black'
          }}
        >
          Energia
        </div>
      </div>
    </div>
  );
};