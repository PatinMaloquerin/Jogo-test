import React, { useEffect, useRef, useState } from 'react';
import { useChatStore } from '../../lib/stores/useChatStore';
import { MessageSquare, X, Send } from 'lucide-react';

export const ChatBox: React.FC = () => {
  const { 
    messages, 
    inputValue, 
    isOpen, 
    addMessage, 
    setInputValue, 
    toggleChat, 
    closeChat,
    processCommand 
  } = useChatStore();
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Auto-scroll para a última mensagem
  useEffect(() => {
    if (messagesEndRef.current && isOpen) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);
  
  // Foca o input quando o chat é aberto
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;
    
    // Verifica se é um comando
    if (inputValue.startsWith('/')) {
      const isCommand = processCommand(inputValue);
      if (isCommand) {
        setInputValue('');
        return;
      }
    }
    
    // Adiciona a mensagem normal
    addMessage(inputValue);
    setInputValue('');
  };
  
  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };
  
  if (!isOpen) {
    return (
      <button 
        className="absolute left-4 top-32 bg-gray-800 p-2 rounded-full text-white opacity-70 hover:opacity-100"
        onClick={toggleChat}
        title="Abrir Chat"
      >
        <MessageSquare size={20} />
      </button>
    );
  }
  
  return (
    <div 
      className={`absolute left-4 bottom-36 bg-gray-800 bg-opacity-80 rounded-lg text-white ${
        isCollapsed ? 'w-12 h-12' : 'w-72 h-64'
      } transition-all duration-200 shadow-lg flex flex-col`}
    >
      {isCollapsed ? (
        <div 
          className="w-full h-full flex items-center justify-center cursor-pointer"
          onClick={toggleCollapse}
        >
          <div className="bg-gray-700 w-6 h-1 rounded-full"></div>
        </div>
      ) : (
        <>
          <div className="flex justify-between items-center p-2 border-b border-gray-700">
            <span className="font-bold text-sm">Chat</span>
            <div className="flex space-x-1">
              <button 
                className="p-1 rounded hover:bg-gray-700"
                onClick={toggleCollapse}
                title="Minimizar"
              >
                <MessageSquare size={16} />
              </button>
              <button 
                className="p-1 rounded hover:bg-gray-700"
                onClick={closeChat}
                title="Fechar"
              >
                <X size={16} />
              </button>
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 scrollbar-thin scrollbar-thumb-gray-700 scrollbar-track-gray-900">
            {messages.length > 0 ? (
              messages.map((msg) => (
                <div 
                  key={msg.id} 
                  className={`mb-1 text-sm ${msg.isSystem ? 'text-yellow-300' : 'text-white'}`}
                >
                  {msg.isSystem ? (
                    <span>{msg.text}</span>
                  ) : (
                    <span>
                      <span className="opacity-70">[{new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}]</span> {msg.text}
                    </span>
                  )}
                </div>
              ))
            ) : (
              <div className="text-center text-gray-400 text-sm mt-2">
                Digite uma mensagem ou use / para comandos
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <form onSubmit={handleSubmit} className="p-2 border-t border-gray-700 flex">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              className="flex-1 bg-gray-700 text-white rounded-l px-2 py-1 text-sm focus:outline-none"
              placeholder="Digite uma mensagem ou comando..."
            />
            <button 
              type="submit" 
              className="bg-blue-600 text-white rounded-r px-2 hover:bg-blue-700"
            >
              <Send size={16} />
            </button>
          </form>
        </>
      )}
    </div>
  );
};