import React from 'react';
import { Projectile as ProjectileType } from '@/lib/types';

interface ProjectileProps {
  projectile: ProjectileType;
}

const Projectile: React.FC<ProjectileProps> = ({ projectile }) => {
  const { size, color } = projectile;
  
  return (
    <div
      className="rounded-full"
      style={{
        width: size.width,
        height: size.height,
        backgroundColor: color,
        boxShadow: `0 0 5px 2px ${color}`,
        zIndex: 5,
      }}
    />
  );
};

export default Projectile;
