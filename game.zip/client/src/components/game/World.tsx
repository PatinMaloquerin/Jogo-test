import React, { useMemo } from 'react';
import Player from './Player';
import Enemy from './Enemy';
import { NPC } from './NPC';
import Projectile from './Projectile';
import { useGameState } from '@/lib/stores/useGameState';

const World: React.FC = () => {
  const { player, enemies, npcs, projectiles, getCanvasDimensions } = useGameState();
  const { width, height } = getCanvasDimensions();
  
  // Calcula o deslocamento da câmera para seguir o jogador
  const cameraOffset = useMemo(() => {
    const centerX = width / 2;
    const centerY = height / 2;
    
    // Subtrai a posição do centro da tela pela posição do jogador
    return {
      x: centerX - player.position.x,
      y: centerY - player.position.y,
    };
  }, [width, height, player.position.x, player.position.y]);
  
  // Generate a simple grid pattern for the background
  const gridSize = 40;
  const horizontalLines = [];
  const verticalLines = [];
  
  // Calcule a quantidade de linhas horizontais e verticais necessárias
  // para cobrir o mundo visível considerando o deslocamento da câmera
  const startX = Math.floor(-cameraOffset.x / gridSize) * gridSize;
  const startY = Math.floor(-cameraOffset.y / gridSize) * gridSize;
  const endX = width - cameraOffset.x + gridSize;
  const endY = height - cameraOffset.y + gridSize;
  
  // Linhas horizontais
  for (let i = startY; i <= endY; i += gridSize) {
    horizontalLines.push(
      <div
        key={`h-${i}`}
        style={{
          position: 'absolute',
          top: i + cameraOffset.y,
          left: 0,
          width: width,
          height: 1,
          backgroundColor: 'rgba(200, 200, 200, 0.2)',
        }}
      />
    );
  }
  
  // Linhas verticais
  for (let i = startX; i <= endX; i += gridSize) {
    verticalLines.push(
      <div
        key={`v-${i}`}
        style={{
          position: 'absolute',
          top: 0,
          left: i + cameraOffset.x,
          width: 1,
          height: height,
          backgroundColor: 'rgba(200, 200, 200, 0.2)',
        }}
      />
    );
  }
  
  return (
    <div
      className="relative bg-slate-800 w-full h-full"
      style={{
        overflow: 'hidden',
      }}
    >
      {/* Grid background */}
      {horizontalLines}
      {verticalLines}
      
      {/* Terrain features could be added here */}
      
      {/* Câmera e camada de entidades */}
      <div
        className="absolute"
        style={{
          transform: `translate(${cameraOffset.x}px, ${cameraOffset.y}px)`,
          width: 0,
          height: 0,
        }}
      >
        {/* Game entities */}
        {npcs.map(npc => (
          <div
            key={npc.id}
            style={{
              position: 'absolute',
              left: npc.position.x,
              top: npc.position.y,
            }}
          >
            <NPC npc={npc} />
          </div>
        ))}
        
        {enemies.map(enemy => (
          <div
            key={enemy.id}
            style={{
              position: 'absolute',
              left: enemy.position.x,
              top: enemy.position.y,
            }}
          >
            <Enemy enemy={enemy} />
          </div>
        ))}
        
        {projectiles.map(projectile => (
          <div
            key={projectile.id}
            style={{
              position: 'absolute',
              left: projectile.position.x,
              top: projectile.position.y,
            }}
          >
            <Projectile projectile={projectile} />
          </div>
        ))}
        
        {/* Player posicionado no mundo */}
        <div
          style={{
            position: 'absolute',
            left: player.position.x,
            top: player.position.y,
          }}
        >
          <Player player={player} />
        </div>
      </div>
    </div>
  );
};

export default World;
