import React, { useEffect, useRef } from 'react';
import { Character as CharacterType, CharacterType as CharacterTypes } from '@/lib/types';
import Character from './Character';

interface EnemyProps {
  enemy: CharacterType;
}

const Enemy: React.FC<EnemyProps> = ({ enemy }) => {
  const prevPositionRef = useRef(enemy.position);
  
  // Visual feedback for different enemy types
  let extraElement = null;
  
  // Add visual indicator for aggressive enemies (fireball shooter)
  if (enemy.type === CharacterTypes.AGGRESSIVE_ENEMY) {
    extraElement = (
      <div
        className="absolute"
        style={{
          top: -18,
          left: '50%',
          transform: 'translateX(-50%)',
          fontSize: 14,
          color: 'orange',
        }}
      >
        🔥
      </div>
    );
  }
  
  // Add visual indicator for provoked state
  if (enemy.isProvoked) {
    extraElement = (
      <div
        className="absolute"
        style={{
          top: -18,
          left: '50%',
          transform: 'translateX(-50%)',
          fontSize: 14,
          color: 'red',
        }}
      >
        !
      </div>
    );
  }
  
  // Update prev position ref
  useEffect(() => {
    prevPositionRef.current = enemy.position;
  }, [enemy.position]);
  
  return (
    <>
      <Character character={enemy} />
      {extraElement}
    </>
  );
};

export default Enemy;
