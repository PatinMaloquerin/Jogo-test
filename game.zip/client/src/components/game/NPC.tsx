import React from 'react';
import { Character, CharacterType, QuestStatus } from '../../lib/types';
import { QuestIndicator } from '../ui/QuestIndicator';
import { useQuestStore } from '../../lib/stores/useQuestStore';

interface NPCProps {
  npc: Character;
}

export const NPC: React.FC<NPCProps> = ({ npc }) => {
  const questStore = useQuestStore();
  
  // Determinar o status da quest para este NPC
  const getQuestStatusForNPC = (npcId: string) => {
    const missionsForNPC = questStore.getMissionsForNPC(npcId);
    
    if (missionsForNPC.length === 0) return undefined;
    
    // Verificar quests em andamento
    const activeQuest = missionsForNPC.find(
      q => questStore.isQuestActive(q.id)
    );
    if (activeQuest) {
      return questStore.isQuestReadyToTurnIn(activeQuest.id) 
        ? QuestStatus.READY_TO_TURN_IN 
        : QuestStatus.IN_PROGRESS;
    }
    
    // Verificar quests completadas
    const completedQuest = missionsForNPC.find(
      q => questStore.isQuestCompleted(q.id)
    );
    if (completedQuest) return QuestStatus.COMPLETED;
    
    // Se tiver alguma missão disponível
    return QuestStatus.AVAILABLE;
  };
  
  const handleNPCClick = () => {
    // Interação com NPC (a ser implementada)
    console.log('Clicou no NPC:', npc.id);
    // Aqui implementaremos diálogos e missões posteriormente
  };
  
  const questStatus = getQuestStatusForNPC(npc.id);
  
  return (
    <div
      style={{
        position: 'absolute',
        left: npc.position.x,
        top: npc.position.y,
        width: npc.size.width,
        height: npc.size.height,
        backgroundColor: npc.color,
        cursor: 'pointer',
        transition: 'transform 0.2s',
        border: '2px solid white',
        borderRadius: '4px',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.3)'
      }}
      onClick={handleNPCClick}
      className="hover:scale-105"
    >
      {/* Indicador de Quest */}
      <QuestIndicator 
        questStatus={questStatus} 
        position={npc.position} 
      />
    </div>
  );
};