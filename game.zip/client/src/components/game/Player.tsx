import React from 'react';
import { Character as CharacterType } from '@/lib/types';
import Character from './Character';

interface PlayerProps {
  player: CharacterType;
}

const Player: React.FC<PlayerProps> = ({ player }) => {
  // Display status effects or animations
  const isLowHealth = player.stats.health < player.stats.maxHealth * 0.3;
  
  return (
    <div className="relative">
      <Character character={player} />
      
      {/* Low health indicator */}
      {isLowHealth && (
        <div
          className="absolute animate-pulse"
          style={{
            top: -15,
            left: '50%',
            transform: 'translateX(-50%)',
            fontSize: 12,
            color: 'red',
          }}
        >
          Low Health!
        </div>
      )}
      
      {/* Attack animation */}
      {player.isAttacking && (
        <div
          className="absolute"
          style={{
            width: 30,
            height: 30,
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            borderRadius: '50%',
            border: '2px solid yellow',
            opacity: 0.6,
            animation: 'attack-pulse 0.3s forwards',
          }}
        />
      )}
      
      <style jsx>{`
        @keyframes attack-pulse {
          0% {
            transform: translate(-50%, -50%) scale(0.5);
            opacity: 0.8;
          }
          100% {
            transform: translate(-50%, -50%) scale(1.5);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};

export default Player;
