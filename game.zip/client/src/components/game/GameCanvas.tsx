import React, { useEffect, useRef } from 'react';
import World from './World';
import GameUI from '../../components/ui/GameUI';
import StatUpgradeMenu from '../../components/ui/StatUpgradeMenu';
import { DialogueBox } from '../../components/ui/DialogueBox';
import { Minimap } from '../../components/ui/Minimap';
import { useGameState } from '../../lib/stores/useGameState';
import { useAudio } from '../../lib/stores/useAudio';
import { useQuestStore } from '../../lib/stores/useQuestStore';
import { Controls } from '../../lib/types';

const GameCanvas: React.FC = () => {
  const { 
    initGame, 
    updateGame, 
    isGameRunning, 
    isGameOver, 
    isUpgradeMenuOpen,
    setControls,
    playerAttack,
    playerMagicAttack,
    playerTransform, // Added for transformation
    resetGame
  } = useGameState();
  
  const controlsRef = useRef<Controls>({
    up: false,
    down: false,
    left: false,
    right: false,
    attack: false,
    magic: false,
    transform: false
  });
  
  const animationFrameRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  
  // Setup audio
  const { setHitSound, setSuccessSound } = useAudio();
  
  useEffect(() => {
    // Load sound effects
    const hitSound = new Audio('/sounds/hit.mp3');
    const successSound = new Audio('/sounds/success.mp3');
    
    setHitSound(hitSound);
    setSuccessSound(successSound);
    
    // Initialize game
    initGame();
    
    // Adicionar um listener de redimensionamento da janela
    const handleResize = () => {
      // A função getCanvasDimensions já obterá o tamanho atualizado
      const dimensions = useGameState.getState().getCanvasDimensions();
      console.log('Janela redimensionada:', dimensions);
    };

    // Adicionar o evento de resize
    window.addEventListener('resize', handleResize);
    
    // Clean up animation frame and event listeners on unmount
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      window.removeEventListener('resize', handleResize);
    };
  }, []);
  
  // Game loop
  useEffect(() => {
    if (!isGameRunning) return;
    
    const gameLoop = (currentTime: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = currentTime;
      }
      
      const deltaTime = currentTime - lastTimeRef.current;
      lastTimeRef.current = currentTime;
      
      // Update game state
      updateGame(deltaTime);
      
      // Request next frame
      animationFrameRef.current = requestAnimationFrame(gameLoop);
    };
    
    // Start game loop
    animationFrameRef.current = requestAnimationFrame(gameLoop);
    
    // Clean up
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isGameRunning, updateGame]);
  
  // Handle keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Only respond to spacebar, E, P, and T key presses for actions
      // Movement now only works with mouse/touch controls
      switch (e.code) {
        case 'Space':
          playerAttack();
          break;
        case 'KeyE':
          playerMagicAttack();
          break;
        case 'KeyP':
          useGameState.getState().toggleUpgradeMenu();
          break;
        case 'KeyT':
          playerTransform();
          break;
      }
    };
    
    // Add event listeners
    window.addEventListener('keydown', handleKeyDown);
    
    // Clean up
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [playerAttack, playerMagicAttack, playerTransform]);
  
  // Handle Game Over
  useEffect(() => {
    if (isGameOver) {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    }
  }, [isGameOver]);
  
  // Inicializar sistema de quests
  useEffect(() => {
    const { initQuests } = useQuestStore.getState();
    initQuests();
  }, []);

  return (
    <div className="relative w-full h-full flex justify-center items-center overflow-hidden">
      <div className="relative w-full h-full">
        <World />
        <GameUI 
          onAttack={playerAttack} 
          onMagicAttack={playerMagicAttack} 
          onUpgradeMenu={useGameState.getState().toggleUpgradeMenu}
          onTransform={playerTransform}
        />
        
        {/* Caixa de diálogo */}
        <DialogueBox />
        
        {/* Minimapa */}
        <Minimap size={180} />
        
        {isUpgradeMenuOpen && <StatUpgradeMenu />}
        
        {isGameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-70 flex flex-col justify-center items-center">
            <h2 className="text-3xl text-white mb-4">Game Over</h2>
            <p className="text-xl text-white mb-8">
              Kills: {useGameState.getState().kills}
            </p>
            <button 
              className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
              onClick={resetGame}
            >
              Play Again
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GameCanvas;
