import React from 'react';
import { Character as CharacterType } from '@/lib/types';

interface CharacterProps {
  character: CharacterType;
}

const Character: React.FC<CharacterProps> = ({ character }) => {
  const { size, stats, isAttacking, type } = character;
  
  // Health bar width as a percentage of character width
  const healthPercentage = (stats.health / stats.maxHealth) * 100;
  
  const characterStyle = type === 'player' ? {
    width: size.width,
    height: size.height,
    backgroundImage: 'url(/imagrfges.png)',
    backgroundSize: 'contain',
    backgroundPosition: 'center',
    backgroundRepeat: 'no-repeat',
    transform: isAttacking ? 'scale(1.1)' : 'scale(1)',
    transition: 'transform 0.2s',
    zIndex: 10,
  } : {
    width: size.width,
    height: size.height,
    backgroundColor: type === 'npc' ? '#4a4' : '#0a0',
    clipPath: type === 'npc' ? 
      'polygon(20% 0%, 80% 0%, 100% 20%, 100% 80%, 80% 100%, 20% 100%, 0% 80%, 0% 20%)' :
      'polygon(30% 0%, 70% 0%, 100% 30%, 100% 70%, 70% 100%, 30% 100%, 0% 70%, 0% 30%)',
    border: '2px solid #060',
    zIndex: 10,
  };

  return (
    <div style={{
      ...characterStyle,
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
    }}>
      {/* Health bar */}
      <div style={{
        position: 'absolute',
        top: -10,
        left: 0,
        width: '100%',
        height: 4,
        backgroundColor: '#333',
      }}>
        <div style={{
          width: `${healthPercentage}%`,
          height: '100%',
          backgroundColor: '#f00',
        }} />
      </div>
      
      {/* Character icon/symbol */}
      <span style={{ color: 'white', fontWeight: 'bold', fontSize: '12px', textAlign: 'center' }}>
        {type === 'player' ? 'P' : 'E'}
      </span>
    </div>
  );
};

export default Character;
