import { Entity, EntityStats, EntityType, Race, createBaseEntity } from './Entity';

export interface PlayerEntity extends Entity {
  statPoints: number;
  level: number;
  experience: number;
  experienceToNextLevel: number;
}

// Configurações de estatísticas iniciais por raça
export const raceBaseStats: Record<Race, EntityStats> = {
  [Race.HUMAN]: {  // Humano - equilibrado
    strength: 5,
    constitution: 5,
    dexterity: 5,
    willpower: 5,
    spirit: 5
  },
  [Race.SAIYAN]: {  // Saiyajin - forte fisicamente
    strength: 8,
    constitution: 6,
    dexterity: 4,
    willpower: 3,
    spirit: 4
  },
  [Race.ARCOSIAN]: {  // Arcosiano - resistente e ágil
    strength: 3,
    constitution: 7,
    dexterity: 7,
    willpower: 4,
    spirit: 4
  },
  [Race.NAMEKIAN]: {  // Namekuseijin - equilibrado com ki forte
    strength: 6,
    constitution: 6,
    dexterity: 4,
    willpower: 3,
    spirit: 6
  }
};

// Cores por raça
export const raceColors: Record<Race, string> = {
  [Race.HUMAN]: '#3498db',     // Azul
  [Race.SAIYAN]: '#e74c3c',    // Vermelho
  [Race.ARCOSIAN]: '#9b59b6',  // Roxo
  [Race.NAMEKIAN]: '#2ecc71'   // Verde
};

// Create a player entity
export const createPlayer = (x: number, y: number, race: Race = Race.HUMAN): PlayerEntity => {
  const baseEntity = createBaseEntity(
    'player',
    x,
    y,
    40, // width
    40, // height
    raceColors[race], // cor baseada na raça
    200, // base speed (pixels per second)
    EntityType.PLAYER
  );
  
  // Initial player stats based on race
  const stats: EntityStats = { ...raceBaseStats[race] };
  
  // Calculate derived attributes based on stats (novos multiplicadores)
  const maxHealth = 100 + (stats.constitution * 20);  // +20 por ponto
  const maxKi = 50 + (stats.spirit * 20);            // +20 por ponto
  const maxStamina = 100 + (stats.dexterity * 5);
  const speed = 200 + (stats.dexterity * 5);
  const resistance = stats.dexterity;                // +1 por ponto
  
  return {
    ...baseEntity,
    health: maxHealth,
    maxHealth,
    ki: maxKi,                    // Renomeado para ki
    maxKi,                        // Renomeado para maxKi
    stamina: maxStamina,
    maxStamina,
    damage: 10 + (stats.strength * 2),  // +2 por ponto de força
    resistance,
    stats,
    statPoints: 5,
    level: 1,
    experience: 0,
    experienceToNextLevel: 100,
    attackCooldown: 500, // ms
    attackRange: 60, // pixels
    isAttacking: false,
    lastAttackTime: 0,
    race,                         // Raça selecionada
    transformation: 0,            // Começa na forma base (0)
    kiDrainTimer: 0,              // Timer para drenagem de ki
    transformationPoints: 0,      // Pontos para comprar transformações
    speed                         // Velocidade atualizada
  };
};

// Increase a specific player stat
export const increasePlayerStat = (
  player: PlayerEntity,
  statName: keyof EntityStats
): PlayerEntity => {
  if (player.statPoints <= 0 || !player.stats) {
    return player;
  }
  
  const updatedStats = { ...player.stats };
  updatedStats[statName] += 1;
  
  // Recalculate derived attributes
  let maxHealth = 100 + (updatedStats.constitution * 10);
  let maxMana = 50 + (updatedStats.spirit * 10);
  let maxStamina = 100 + (updatedStats.dexterity * 5);
  const speed = 200 + (updatedStats.dexterity * 5);
  const damage = 10 + Math.floor(updatedStats.strength * 0.5);
  
  // Calculate health difference to adjust current health proportionally
  const healthRatio = player.health! / player.maxHealth!;
  const manaRatio = player.mana! / player.maxMana!;
  const staminaRatio = player.stamina! / player.maxStamina!;
  
  return {
    ...player,
    stats: updatedStats,
    statPoints: player.statPoints - 1,
    maxHealth,
    health: Math.floor(maxHealth * healthRatio),
    maxMana,
    mana: Math.floor(maxMana * manaRatio),
    maxStamina,
    stamina: Math.floor(maxStamina * staminaRatio),
    speed,
    damage
  };
};

// Handle player leveling up
export const levelUpPlayer = (player: PlayerEntity): PlayerEntity => {
  return {
    ...player,
    level: player.level + 1,
    statPoints: player.statPoints + 3, // Award stat points on level up
    experience: player.experience - player.experienceToNextLevel,
    experienceToNextLevel: Math.floor(player.experienceToNextLevel * 1.5) // Next level requires more XP
  };
};

// Grant experience to player
export const grantExperience = (player: PlayerEntity, amount: number): PlayerEntity => {
  const newExperience = player.experience + amount;
  
  if (newExperience >= player.experienceToNextLevel) {
    return levelUpPlayer({
      ...player,
      experience: newExperience
    });
  }
  
  return {
    ...player,
    experience: newExperience
  };
};
