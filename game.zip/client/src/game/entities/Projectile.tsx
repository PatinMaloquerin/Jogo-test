import { Entity, EntityType, createBaseEntity } from './Entity';
import { v4 as uuidv4 } from 'uuid';

export interface Projectile extends Entity {
  directionX: number;
  directionY: number;
  sourceId: string;
  radius: number;
  lifespan: number;
  createdAt: number;
}

// Create a projectile (like a fireball)
export const createProjectile = (
  x: number, 
  y: number, 
  directionX: number, 
  directionY: number, 
  sourceId: string,
  damage: number,
  color: string = '#e67e22' // Orange by default (fireball)
): Projectile => {
  const radius = 8;
  const baseEntity = createBaseEntity(
    `projectile-${uuidv4().slice(0, 8)}`,
    x,
    y,
    radius * 2, // width
    radius * 2, // height
    color,
    300, // speed (pixels per second)
    EntityType.PROJECTILE
  );
  
  return {
    ...baseEntity,
    directionX,
    directionY,
    sourceId,
    radius,
    damage,
    lifespan: 3000, // milliseconds before disappearing
    createdAt: Date.now()
  };
};

// Move projectile based on its direction and speed
export const moveProjectile = (
  projectile: Projectile,
  deltaTime: number
): Projectile => {
  // Check if projectile has exceeded its lifespan
  if (Date.now() - projectile.createdAt > projectile.lifespan) {
    return {
      ...projectile,
      active: false
    };
  }
  
  // Move projectile in its direction
  return {
    ...projectile,
    x: projectile.x + projectile.directionX * projectile.speed * deltaTime,
    y: projectile.y + projectile.directionY * projectile.speed * deltaTime
  };
};

// Create a fireball projectile
export const createFireball = (
  sourceEntity: Entity,
  targetX: number,
  targetY: number
): Projectile => {
  // Calculate direction from source to target position
  const dx = targetX - sourceEntity.x;
  const dy = targetY - sourceEntity.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // Normalize direction
  const directionX = distance > 0 ? dx / distance : 0;
  const directionY = distance > 0 ? dy / distance : 0;
  
  // Calculate damage based on source entity's willpower stat
  const damage = sourceEntity.stats 
    ? 5 + Math.floor(sourceEntity.stats.willpower * 0.8)
    : 5;
  
  // Create the projectile slightly away from the source entity in the direction of the target
  const offsetX = directionX * (sourceEntity.width / 2 + 10);
  const offsetY = directionY * (sourceEntity.height / 2 + 10);
  
  return createProjectile(
    sourceEntity.x + offsetX,
    sourceEntity.y + offsetY,
    directionX,
    directionY,
    sourceEntity.id,
    damage,
    '#e67e22' // Orange color for fireball
  );
};
