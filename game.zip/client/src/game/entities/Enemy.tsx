import { Entity, EntityStats, EntityType, createBaseEntity } from './Entity';
import { v4 as uuidv4 } from 'uuid';

// Create a wanderer enemy (only attacks when provoked)
export const createWandererEnemy = (x: number, y: number): Entity => {
  const baseEntity = createBaseEntity(
    `wanderer-${uuidv4().slice(0, 8)}`,
    x,
    y,
    35, // width
    35, // height
    '#e74c3c', // color - red
    80, // speed (pixels per second)
    EntityType.WANDERER_ENEMY
  );
  
  // Enemy stats
  const stats: EntityStats = {
    strength: 3,
    constitution: 3,
    dexterity: 2,
    willpower: 1,
    spirit: 1
  };
  
  // Calculate derived attributes
  const maxHealth = 50 + (stats.constitution * 5);
  
  return {
    ...baseEntity,
    health: maxHealth,
    maxHealth,
    damage: 5 + Math.floor(stats.strength * 0.5),
    stats,
    isAggressive: false, // Only becomes aggressive when attacked
    wasAttacked: false,
    attackCooldown: 1000, // ms
    attackRange: 50, // pixels
    isAttacking: false,
    lastAttackTime: 0,
    targetId: null
  };
};

// Create a shooter enemy (attacks with fireballs)
export const createShooterEnemy = (x: number, y: number): Entity => {
  const baseEntity = createBaseEntity(
    `shooter-${uuidv4().slice(0, 8)}`,
    x,
    y,
    30, // width
    30, // height
    '#8e44ad', // color - purple
    60, // speed (pixels per second)
    EntityType.SHOOTER_ENEMY
  );
  
  // Enemy stats
  const stats: EntityStats = {
    strength: 2,
    constitution: 2,
    dexterity: 2,
    willpower: 5,
    spirit: 3
  };
  
  // Calculate derived attributes
  const maxHealth = 40 + (stats.constitution * 5);
  const maxMana = 50 + (stats.spirit * 10);
  
  return {
    ...baseEntity,
    health: maxHealth,
    maxHealth,
    mana: maxMana,
    maxMana,
    damage: 3 + Math.floor(stats.willpower * 0.5),
    stats,
    isAggressive: true, // Always aggressive
    attackCooldown: 2000, // ms
    attackRange: 200, // pixels - shoot from further away
    isAttacking: false,
    lastAttackTime: 0,
    targetId: null
  };
};

// Move enemy toward a target if aggressive or provoked
export const moveEnemyTowardTarget = (
  enemy: Entity,
  targetEntity: Entity,
  deltaTime: number
): Entity => {
  // Don't move if not aggressive and not provoked
  if (!enemy.isAggressive && !enemy.wasAttacked) {
    return enemy;
  }
  
  // Calculate direction to target
  const dx = targetEntity.x - enemy.x;
  const dy = targetEntity.y - enemy.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // If within attack range, don't move closer
  if (distance <= (enemy.attackRange || 50)) {
    return {
      ...enemy,
      targetId: targetEntity.id
    };
  }
  
  // Normalize direction vector
  const dirX = dx / distance;
  const dirY = dy / distance;
  
  // Move toward target
  return {
    ...enemy,
    x: enemy.x + dirX * enemy.speed * deltaTime,
    y: enemy.y + dirY * enemy.speed * deltaTime,
    targetId: targetEntity.id
  };
};

// Make enemy wander randomly
export const moveEnemyRandomly = (
  enemy: Entity,
  deltaTime: number
): Entity => {
  // Only wander if not aggressive and not provoked
  if (enemy.isAggressive || enemy.wasAttacked) {
    return enemy;
  }
  
  // Create random movement based on time
  const time = Date.now() / 1000;
  const dirX = Math.sin(time * 0.5 + parseInt(enemy.id.slice(-3), 16));
  const dirY = Math.cos(time * 0.3 + parseInt(enemy.id.slice(-3), 16));
  
  // Move at a slower pace when wandering
  const wanderSpeed = enemy.speed * 0.3;
  
  return {
    ...enemy,
    x: enemy.x + dirX * wanderSpeed * deltaTime,
    y: enemy.y + dirY * wanderSpeed * deltaTime
  };
};
