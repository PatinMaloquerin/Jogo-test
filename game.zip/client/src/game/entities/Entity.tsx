// Base entity interface that all game objects inherit from
export interface Entity {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  speed: number;
  active: boolean;
  health?: number;
  maxHealth?: number;
  ki?: number;           // Renamed from mana to ki
  maxKi?: number;        // Renamed from maxMana to maxKi
  stamina?: number;
  maxStamina?: number;
  damage?: number;
  resistance?: number;   // Nova propriedade para resistência a dano
  stats?: EntityStats;
  type: EntityType;
  isAttacking?: boolean;
  lastAttackTime?: number;
  attackCooldown?: number;
  isAggressive?: boolean;
  wasAttacked?: boolean;
  attackRange?: number;
  targetId?: string | null;
  race?: Race;           // Nova propriedade para raça do personagem
  transformation?: number; // Nível de transformação (0 = base form, 1 = primeira forma, etc)
  kiDrainTimer?: number;  // Temporizador para drenagem de ki durante transformação
  transformationPoints?: number; // Pontos para comprar novas transformações
}

export interface EntityStats {
  strength: number;     // Affects damage (+2 por ponto)
  constitution: number; // Affects health (+20 por ponto)
  dexterity: number;    // Affects speed and resistance (+1 velocidade, +1 resistência por ponto)
  willpower: number;    // Affects ki attack damage (+2 por ponto)
  spirit: number;       // Affects ki amount (+20 por ponto)
}

export enum EntityType {
  PLAYER = 'player',
  WANDERER_ENEMY = 'wanderer_enemy',
  SHOOTER_ENEMY = 'shooter_enemy',
  NPC = 'npc',
  PROJECTILE = 'projectile'
}

export enum Race {
  HUMAN = 'human',
  SAIYAN = 'saiyan',
  ARCOSIAN = 'arcosian',
  NAMEKIAN = 'namekian'
}

// Factory function to create a base entity
export const createBaseEntity = (
  id: string,
  x: number,
  y: number,
  width: number,
  height: number,
  color: string,
  speed: number,
  type: EntityType
): Entity => {
  return {
    id,
    x,
    y,
    width,
    height,
    color,
    speed,
    active: true,
    type
  };
};

// Function to check collision between two entities
export const checkEntityCollision = (entity1: Entity, entity2: Entity): boolean => {
  return (
    entity1.x < entity2.x + entity2.width &&
    entity1.x + entity1.width > entity2.x &&
    entity1.y < entity2.y + entity2.height &&
    entity1.y + entity1.height > entity2.y
  );
};

// Calculate distance between two entities
export const getDistance = (entity1: Entity, entity2: Entity): number => {
  const dx = entity1.x - entity2.x;
  const dy = entity1.y - entity2.y;
  return Math.sqrt(dx * dx + dy * dy);
};

// Calculate normalized direction vector from one entity to another
export const getDirectionVector = (from: Entity, to: Entity): { x: number, y: number } => {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  if (distance === 0) {
    return { x: 0, y: 0 };
  }
  
  return {
    x: dx / distance,
    y: dy / distance
  };
};

// Fator de multiplicação para transformações
export const getTransformationMultiplier = (transformationLevel: number = 0): number => {
  if (transformationLevel <= 0) return 1.0; // Forma base
  return 1.0 + (transformationLevel * 0.25); // 1ª = 1.25x, 2ª = 1.5x, etc.
};

// Calculate damage based on stats with new rules for DBZ-like system
export const calculateDamage = (attacker: Entity, defender: Entity): number => {
  if (!attacker.stats || !defender.stats || !attacker.damage) {
    return attacker.damage || 5; // Default damage if stats not available
  }
  
  // Aplica o multiplicador de transformação aos atributos
  const transformationMultiplier = getTransformationMultiplier(attacker.transformation);
  
  // Determina se é ataque físico ou de ki
  const isKiAttack = attacker.type === EntityType.PROJECTILE;
  
  // Calcula dano base
  let baseDamage;
  if (isKiAttack) {
    // Dano de ki baseado em força-ki (willpower)
    baseDamage = attacker.damage + (attacker.stats.willpower * 2);
  } else {
    // Dano físico baseado em força
    baseDamage = attacker.damage + (attacker.stats.strength * 2);
  }
  
  // Aplica o multiplicador de transformação
  baseDamage = Math.floor(baseDamage * transformationMultiplier);
  
  // Resistência do defensor (baseada em destreza)
  const resistance = defender.resistance || defender.stats.dexterity;
  
  // Calcula dano final
  const finalDamage = Math.max(0, baseDamage - resistance);
  
  // Retorna pelo menos 1 de dano se houve um acerto, a menos que a resistência seja maior que o dano
  return finalDamage > 0 ? finalDamage : 0;
};
