import { Entity, EntityStats, EntityType, createBaseEntity } from './Entity';
import { v4 as uuidv4 } from 'uuid';

// Create an NPC entity (neutral but will defend if attacked)
export const createNPC = (x: number, y: number, name: string): Entity => {
  const baseEntity = createBaseEntity(
    `npc-${uuidv4().slice(0, 8)}`,
    x,
    y,
    32, // width
    32, // height
    '#27ae60', // color - green
    70, // speed (pixels per second)
    EntityType.NPC
  );
  
  // NPC stats
  const stats: EntityStats = {
    strength: 4,
    constitution: 4,
    dexterity: 3,
    willpower: 2,
    spirit: 2
  };
  
  // Calculate derived attributes
  const maxHealth = 60 + (stats.constitution * 5);
  
  return {
    ...baseEntity,
    name,
    health: maxHealth,
    maxHealth,
    damage: 7 + Math.floor(stats.strength * 0.5),
    stats,
    isAggressive: false, // Only attacks when provoked
    wasAttacked: false,
    attackCooldown: 1200, // ms
    attackRange: 45, // pixels
    isAttacking: false,
    lastAttackTime: 0,
    targetId: null
  };
};

// Move NPC toward a target if it was attacked
export const moveNPCTowardAttacker = (
  npc: Entity,
  attackerEntity: Entity,
  deltaTime: number
): Entity => {
  // Don't move if not attacked
  if (!npc.wasAttacked) {
    return npc;
  }
  
  // Calculate direction to attacker
  const dx = attackerEntity.x - npc.x;
  const dy = attackerEntity.y - npc.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  // If within attack range, don't move closer
  if (distance <= (npc.attackRange || 45)) {
    return {
      ...npc,
      targetId: attackerEntity.id
    };
  }
  
  // Normalize direction vector
  const dirX = dx / distance;
  const dirY = dy / distance;
  
  // Move toward attacker
  return {
    ...npc,
    x: npc.x + dirX * npc.speed * deltaTime,
    y: npc.y + dirY * npc.speed * deltaTime,
    targetId: attackerEntity.id
  };
};

// Make NPC idle (small random movements)
export const moveNPCIdle = (
  npc: Entity,
  deltaTime: number
): Entity => {
  // Don't idle if attacked
  if (npc.wasAttacked) {
    return npc;
  }
  
  // Create very small random movement based on time
  const time = Date.now() / 1000;
  const dirX = Math.sin(time * 0.2 + parseInt(npc.id.slice(-3), 16)) * 0.3;
  const dirY = Math.cos(time * 0.1 + parseInt(npc.id.slice(-3), 16)) * 0.3;
  
  // Move at a very slow pace when idle
  const idleSpeed = npc.speed * 0.1;
  
  return {
    ...npc,
    x: npc.x + dirX * idleSpeed * deltaTime,
    y: npc.y + dirY * idleSpeed * deltaTime
  };
};
