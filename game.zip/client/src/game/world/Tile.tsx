// Define the different types of tiles in the game
export enum TileType {
  GRASS = 'grass',
  DIRT = 'dirt',
  WATER = 'water',
  SAND = 'sand',
  STONE = 'stone'
}

// Interface for a game tile
export interface GameTile {
  type: TileType;
  walkable: boolean;
}

// Create a tile of the specified type
export const createTile = (type: TileType): GameTile => {
  // Determine if the tile is walkable based on its type
  const walkable = type !== TileType.WATER && type !== TileType.STONE;
  
  return {
    type,
    walkable
  };
};

// Check if a particular position is walkable
export const isWalkablePosition = (
  map: GameTile[][],
  x: number,
  y: number,
  tileSize: number = 64
): boolean => {
  // Convert world coordinates to grid coordinates
  const gridX = Math.floor(x / tileSize);
  const gridY = Math.floor(y / tileSize);
  
  // Check if position is out of bounds
  if (
    gridX < 0 ||
    gridX >= map[0].length ||
    gridY < 0 ||
    gridY >= map.length
  ) {
    return false;
  }
  
  // Return whether the tile is walkable
  return map[gridY][gridX].walkable;
};
