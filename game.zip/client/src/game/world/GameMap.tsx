import { GameTile, TileType, createTile } from './Tile';

// Create a game map with the specified dimensions
export const createGameMap = (width: number, height: number): GameTile[][] => {
  const map: GameTile[][] = [];
  
  // Initialize the map with grass tiles
  for (let y = 0; y < height; y++) {
    const row: GameTile[] = [];
    for (let x = 0; x < width; x++) {
      row.push(createTile(TileType.GRASS));
    }
    map.push(row);
  }
  
  // Add some dirt patches
  addPatches(map, TileType.DIRT, 5, 3, 7);
  
  // Add some water bodies
  addPatches(map, TileType.WATER, 3, 5, 10);
  
  // Add some sand areas (often near water)
  addSandAroundWater(map);
  
  // Add some stone patches
  addPatches(map, TileType.STONE, 4, 2, 5);
  
  return map;
};

// Add random patches of a specific tile type
const addPatches = (
  map: GameTile[][],
  tileType: TileType,
  numPatches: number,
  minSize: number,
  maxSize: number
) => {
  for (let i = 0; i < numPatches; i++) {
    // Random center position for the patch
    const centerX = Math.floor(Math.random() * map[0].length);
    const centerY = Math.floor(Math.random() * map.length);
    
    // Random size for the patch
    const patchSize = minSize + Math.floor(Math.random() * (maxSize - minSize + 1));
    
    // Create the patch
    for (let y = centerY - patchSize; y <= centerY + patchSize; y++) {
      for (let x = centerX - patchSize; x <= centerX + patchSize; x++) {
        // Skip if outside map bounds
        if (y < 0 || y >= map.length || x < 0 || x >= map[0].length) {
          continue;
        }
        
        // Calculate distance from center
        const distance = Math.sqrt(Math.pow(x - centerX, 2) + Math.pow(y - centerY, 2));
        
        // The further from the center, the less likely to place a tile
        if (distance <= patchSize * 0.8 || (distance <= patchSize && Math.random() < 0.5)) {
          map[y][x] = createTile(tileType);
        }
      }
    }
  }
};

// Add sand around water tiles
const addSandAroundWater = (map: GameTile[][]) => {
  // First, create a copy of the map to avoid changing the map while iterating
  const mapCopy: TileType[][] = map.map(row => row.map(tile => tile.type));
  
  // Find water tiles and add sand around them
  for (let y = 0; y < map.length; y++) {
    for (let x = 0; x < map[0].length; x++) {
      // If the tile is water, add sand around it
      if (mapCopy[y][x] === TileType.WATER) {
        // Check all 8 surrounding tiles
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            // Skip the water tile itself
            if (dx === 0 && dy === 0) {
              continue;
            }
            
            const newY = y + dy;
            const newX = x + dx;
            
            // Skip if outside map bounds
            if (newY < 0 || newY >= map.length || newX < 0 || newX >= map[0].length) {
              continue;
            }
            
            // If the tile is not water, make it sand (but don't override existing sand)
            if (mapCopy[newY][newX] !== TileType.WATER && map[newY][newX].type !== TileType.SAND) {
              // Use probability to make it look natural
              if (Math.random() < 0.75) {
                map[newY][newX] = createTile(TileType.SAND);
              }
            }
          }
        }
      }
    }
  }
};

// Get a random position on the map that is not water or stone
export const getRandomWalkablePosition = (
  map: GameTile[][],
  padding: number = 2
): { x: number, y: number } => {
  const tileSize = 64;
  let x, y;
  
  do {
    // Pick a random position with padding from the edges
    x = padding + Math.floor(Math.random() * (map[0].length - 2 * padding));
    y = padding + Math.floor(Math.random() * (map.length - 2 * padding));
  } while (
    map[y][x].type === TileType.WATER ||
    map[y][x].type === TileType.STONE
  );
  
  // Convert grid position to world position
  return {
    x: x * tileSize + tileSize / 2,
    y: y * tileSize + tileSize / 2
  };
};
