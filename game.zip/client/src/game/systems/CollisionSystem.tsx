import { Entity, checkEntityCollision, calculateDamage } from '../entities/Entity';
import { Projectile } from '../entities/Projectile';
import { useAudio } from '../../lib/stores/useAudio';

// Check all collisions in the game
export const checkCollisions = (
  player: Entity,
  enemies: Entity[],
  npcs: Entity[],
  projectiles: Projectile[],
  updateGame: (updates: any) => void
) => {
  const updates: any = {};
  const audio = useAudio.getState();
  
  // Check player attacks against enemies
  if (player.isAttacking) {
    enemies.forEach(enemy => {
      if (enemy.active && isInAttackRange(player, enemy)) {
        const damage = calculateDamage(player, enemy);
        const newHealth = Math.max(0, (enemy.health || 0) - damage);
        
        // Play hit sound
        audio.playHit();
        
        // Update enemy state
        updates[enemy.id] = {
          ...enemy,
          health: newHealth,
          wasAttacked: true,
          active: newHealth > 0
        };
        
        // If enemy died, grant experience to player
        if (newHealth <= 0) {
          updates.player = {
            ...player,
            experience: player.experience + 20
          };
          
          // Play success sound
          audio.playSuccess();
        }
      }
    });
    
    // Check player attacks against NPCs
    npcs.forEach(npc => {
      if (npc.active && isInAttackRange(player, npc)) {
        const damage = calculateDamage(player, npc);
        const newHealth = Math.max(0, (npc.health || 0) - damage);
        
        // Play hit sound
        audio.playHit();
        
        // Update NPC state
        updates[npc.id] = {
          ...npc,
          health: newHealth,
          wasAttacked: true,
          targetId: player.id,
          active: newHealth > 0
        };
      }
    });
  }
  
  // Check enemy attacks against player
  enemies.forEach(enemy => {
    if (enemy.active && enemy.isAttacking && isInAttackRange(enemy, player)) {
      const damage = calculateDamage(enemy, player);
      const newHealth = Math.max(0, (player.health || 0) - damage);
      
      // Play hit sound
      audio.playHit();
      
      // Update player state
      updates.player = {
        ...player,
        health: newHealth
      };
    }
  });
  
  // Check NPC attacks against player (if player attacked them first)
  npcs.forEach(npc => {
    if (npc.active && npc.wasAttacked && npc.isAttacking && npc.targetId === player.id && isInAttackRange(npc, player)) {
      const damage = calculateDamage(npc, player);
      const newHealth = Math.max(0, (player.health || 0) - damage);
      
      // Play hit sound
      audio.playHit();
      
      // Update player state
      updates.player = {
        ...player,
        health: newHealth
      };
    }
  });
  
  // Check projectile collisions
  projectiles.forEach(projectile => {
    if (!projectile.active) return;
    
    // Projectile collision with player (if not from player)
    if (projectile.sourceId !== player.id && checkEntityCollision(projectile, player)) {
      const newHealth = Math.max(0, (player.health || 0) - (projectile.damage || 5));
      
      // Play hit sound
      audio.playHit();
      
      // Update player state and deactivate projectile
      updates.player = {
        ...player,
        health: newHealth
      };
      
      updates[projectile.id] = {
        ...projectile,
        active: false
      };
    }
    
    // Projectile collision with enemies (if from player)
    if (projectile.sourceId === player.id) {
      enemies.forEach(enemy => {
        if (enemy.active && checkEntityCollision(projectile, enemy)) {
          const newHealth = Math.max(0, (enemy.health || 0) - (projectile.damage || 5));
          
          // Play hit sound
          audio.playHit();
          
          // Update enemy state and deactivate projectile
          updates[enemy.id] = {
            ...enemy,
            health: newHealth,
            wasAttacked: true,
            active: newHealth > 0
          };
          
          updates[projectile.id] = {
            ...projectile,
            active: false
          };
          
          // If enemy died, grant experience to player
          if (newHealth <= 0) {
            updates.player = {
              ...player,
              experience: player.experience + 20
            };
            
            // Play success sound
            audio.playSuccess();
          }
        }
      });
      
      // Projectile collision with NPCs (if from player)
      npcs.forEach(npc => {
        if (npc.active && checkEntityCollision(projectile, npc)) {
          const newHealth = Math.max(0, (npc.health || 0) - (projectile.damage || 5));
          
          // Play hit sound
          audio.playHit();
          
          // Update NPC state and deactivate projectile
          updates[npc.id] = {
            ...npc,
            health: newHealth,
            wasAttacked: true,
            targetId: player.id,
            active: newHealth > 0
          };
          
          updates[projectile.id] = {
            ...projectile,
            active: false
          };
        }
      });
    }
  });
  
  // Apply all updates
  if (Object.keys(updates).length > 0) {
    updateGame(updates);
  }
};

// Check if target is within attacker's attack range
const isInAttackRange = (attacker: Entity, target: Entity): boolean => {
  const dx = target.x - attacker.x;
  const dy = target.y - attacker.y;
  const distance = Math.sqrt(dx * dx + dy * dy);
  
  return distance <= (attacker.attackRange || 50);
};
