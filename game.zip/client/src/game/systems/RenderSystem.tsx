import { Entity } from '../entities/Entity';
import { GameTile, TileType } from '../world/Tile';
import { createGameMap } from '../world/GameMap';

// Cache the game map
let gameMap: GameTile[][] | null = null;

// Create a map if it doesn't exist
const getGameMap = () => {
  if (!gameMap) {
    gameMap = createGameMap(50, 50);
  }
  return gameMap;
};

// Render the game map
export const renderMap = (
  ctx: CanvasRenderingContext2D,
  player: Entity
) => {
  const map = getGameMap();
  
  // Calculate which tiles are visible
  const canvasWidth = ctx.canvas.width;
  const canvasHeight = ctx.canvas.height;
  
  // Tile size
  const tileSize = 64;
  
  // Calculate the player's position in the grid
  const playerGridX = Math.floor(player.x / tileSize);
  const playerGridY = Math.floor(player.y / tileSize);
  
  // Calculate how many tiles fit on screen
  const tilesX = Math.ceil(canvasWidth / tileSize) + 2;
  const tilesY = Math.ceil(canvasHeight / tileSize) + 2;
  
  // Calculate the starting tile indices
  const startX = Math.max(0, playerGridX - Math.floor(tilesX / 2));
  const startY = Math.max(0, playerGridY - Math.floor(tilesY / 2));
  
  // Calculate the ending tile indices
  const endX = Math.min(map[0].length - 1, startX + tilesX);
  const endY = Math.min(map.length - 1, startY + tilesY);
  
  // Render visible tiles
  for (let y = startY; y <= endY; y++) {
    for (let x = startX; x <= endX; x++) {
      const tile = map[y][x];
      
      // Calculate screen position
      const screenX = Math.round(canvasWidth / 2 + (x * tileSize - player.x));
      const screenY = Math.round(canvasHeight / 2 + (y * tileSize - player.y));
      
      // Render tile based on type
      switch (tile.type) {
        case TileType.GRASS:
          ctx.fillStyle = '#7ccc63';
          break;
        case TileType.DIRT:
          ctx.fillStyle = '#a67c52';
          break;
        case TileType.WATER:
          ctx.fillStyle = '#4286f4';
          break;
        case TileType.SAND:
          ctx.fillStyle = '#e8d890';
          break;
        case TileType.STONE:
          ctx.fillStyle = '#7a7a7a';
          break;
        default:
          ctx.fillStyle = '#7ccc63'; // Default to grass
      }
      
      // Draw the tile
      ctx.fillRect(screenX, screenY, tileSize, tileSize);
      
      // Add a subtle grid line
      ctx.strokeStyle = 'rgba(0,0,0,0.1)';
      ctx.lineWidth = 1;
      ctx.strokeRect(screenX, screenY, tileSize, tileSize);
    }
  }
};

// Render UI elements for entities (like health bars, names, etc.)
export const renderEntityUI = (
  ctx: CanvasRenderingContext2D,
  entity: Entity,
  screenX: number,
  screenY: number
) => {
  // Draw health bar if entity has health
  if (entity.health !== undefined && entity.maxHealth !== undefined) {
    const healthPercentage = Math.max(0, entity.health / entity.maxHealth);
    const barWidth = entity.width;
    const barHeight = 4;
    const barX = screenX - entity.width / 2;
    const barY = screenY - entity.height / 2 - 10;
    
    // Draw background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.fillRect(barX, barY, barWidth, barHeight);
    
    // Draw health
    ctx.fillStyle = 'rgba(220, 50, 50, 0.8)';
    ctx.fillRect(barX, barY, barWidth * healthPercentage, barHeight);
  }
  
  // Draw entity name if it has one
  if ('name' in entity) {
    ctx.font = '12px Arial';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'bottom';
    ctx.fillText(
      entity.name as string,
      screenX,
      screenY - entity.height / 2 - 15
    );
  }
};
