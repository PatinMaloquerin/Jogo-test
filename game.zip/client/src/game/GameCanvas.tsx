import React, { useEffect, useRef } from 'react';
import { useRPGGame } from '../lib/stores/useRPGGame';
import { usePlayer } from '../lib/stores/usePlayer';
import { renderMap } from './systems/RenderSystem';
import { checkCollisions } from './systems/CollisionSystem';
import { Entity } from './entities/Entity';

const GameCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { 
    gameState, 
    enemies, 
    npcs, 
    projectiles, 
    updateGame, 
    moveEnemy,
    moveProjectile
  } = useRPGGame();
  const { player, movePlayer } = usePlayer();
  
  // Set up the game loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle keyboard input
    const keys: { [key: string]: boolean } = {};
    
    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key] = true;
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key] = false;
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    // Game loop
    let animationFrameId: number;
    let lastTime = 0;
    
    const gameLoop = (timestamp: number) => {
      // Calculate delta time
      const deltaTime = lastTime ? (timestamp - lastTime) / 1000 : 0;
      lastTime = timestamp;
      
      // Clear the canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Resize canvas to window size if needed
      if (canvas.width !== window.innerWidth || canvas.height !== window.innerHeight) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
      }
      
      // Handle player movement based on keyboard input
      const speed = player.speed * deltaTime;
      let dx = 0;
      let dy = 0;
      
      if (keys['ArrowUp'] || keys['w'] || keys['W']) dy -= speed;
      if (keys['ArrowDown'] || keys['s'] || keys['S']) dy += speed;
      if (keys['ArrowLeft'] || keys['a'] || keys['A']) dx -= speed;
      if (keys['ArrowRight'] || keys['d'] || keys['D']) dx += speed;
      
      if (dx !== 0 || dy !== 0) {
        movePlayer(dx, dy);
      }
      
      // Render the game
      renderMap(ctx, player);
      
      // Move and render enemies
      enemies.forEach(enemy => {
        if (enemy.active) {
          moveEnemy(enemy, player, deltaTime);
          renderEntity(ctx, enemy, player);
        }
      });
      
      // Move and render NPCs
      npcs.forEach(npc => {
        if (npc.active) {
          renderEntity(ctx, npc, player);
        }
      });
      
      // Move and render projectiles
      projectiles.forEach(projectile => {
        if (projectile.active) {
          moveProjectile(projectile, deltaTime);
          renderProjectile(ctx, projectile, player);
        }
      });
      
      // Render player at center of screen
      renderPlayer(ctx);
      
      // Check collisions
      checkCollisions(player, enemies, npcs, projectiles, updateGame);
      
      // Continue the game loop
      animationFrameId = requestAnimationFrame(gameLoop);
    };
    
    // Start the game loop
    animationFrameId = requestAnimationFrame(gameLoop);
    
    // Cleanup function
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      cancelAnimationFrame(animationFrameId);
    };
  }, [player, enemies, npcs, projectiles]);
  
  // Render entity relative to player position
  const renderEntity = (ctx: CanvasRenderingContext2D, entity: Entity, player: Entity) => {
    const screenX = window.innerWidth / 2 + (entity.x - player.x);
    const screenY = window.innerHeight / 2 + (entity.y - player.y);
    
    // Draw the entity
    ctx.fillStyle = entity.color;
    ctx.fillRect(screenX - entity.width / 2, screenY - entity.height / 2, entity.width, entity.height);
    
    // Draw health bar if entity has health
    if (entity.health !== undefined && entity.maxHealth !== undefined) {
      const healthPercentage = Math.max(0, entity.health / entity.maxHealth);
      
      ctx.fillStyle = 'black';
      ctx.fillRect(screenX - 15, screenY - entity.height / 2 - 10, 30, 5);
      
      ctx.fillStyle = 'red';
      ctx.fillRect(screenX - 15, screenY - entity.height / 2 - 10, 30 * healthPercentage, 5);
    }
  };
  
  // Render player at the center of the screen
  const renderPlayer = (ctx: CanvasRenderingContext2D) => {
    const screenX = window.innerWidth / 2;
    const screenY = window.innerHeight / 2;
    
    // Draw the player
    ctx.fillStyle = player.color;
    ctx.fillRect(screenX - player.width / 2, screenY - player.height / 2, player.width, player.height);
  };
  
  // Render projectile relative to player position
  const renderProjectile = (ctx: CanvasRenderingContext2D, projectile: any, player: Entity) => {
    const screenX = window.innerWidth / 2 + (projectile.x - player.x);
    const screenY = window.innerHeight / 2 + (projectile.y - player.y);
    
    // Draw the projectile
    ctx.fillStyle = projectile.color;
    ctx.beginPath();
    ctx.arc(screenX, screenY, projectile.radius, 0, Math.PI * 2);
    ctx.fill();
  };
  
  return (
    <canvas 
      ref={canvasRef} 
      className="absolute top-0 left-0 w-full h-full"
    />
  );
};

export default GameCanvas;
