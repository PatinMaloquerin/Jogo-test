import { create } from 'zustand';
import { 
  GameState, 
  Character, 
  CharacterType, 
  Projectile, 
  Position,
  Controls,
  CharacterStats,
  DamageText
} from '../types';
import { 
  createCharacter, 
  createProjectile, 
  calculateDamage, 
  calculateKiDamage,
  applyDamage,
  canAttack,
  applyStatUpgrade,
  awardExperience,
  createDamageText,
  checkHealthRegeneration,
  handleTransformationKiDrain,
  applyTransformation,
  getTransformationMultiplier,
  generateId
} from '../utils/gameUtils';
import { 
  checkCollision,
  checkProjectileCollision, 
  checkCharacterCollisions,
  resolveCollision,
  isInBounds
} from '../utils/collision';
import { useAudio } from './useAudio';
import { useQuestStore } from './useQuestStore';
import { QuestType } from '../types/quest';

// Função para obter as dimensões atuais da janela
const getWindowDimensions = () => {
  // Fallback para valores padrão caso esteja em um ambiente sem window
  const defaultWidth = 960;
  const defaultHeight = 540;
  
  if (typeof window === 'undefined') {
    return { width: defaultWidth, height: defaultHeight };
  }
  
  return {
    width: window.innerWidth,
    height: window.innerHeight
  };
};

// Canvas dimensions iniciais
let CANVAS_WIDTH = getWindowDimensions().width;
let CANVAS_HEIGHT = getWindowDimensions().height;

// Cooldown times in milliseconds
const ATTACK_COOLDOWN = 500;
const MAGIC_COOLDOWN = 1000;
const ENEMY_ATTACK_COOLDOWN = 1500;

// Initial player position
const INITIAL_PLAYER_POSITION: Position = {
  x: CANVAS_WIDTH / 2,
  y: CANVAS_HEIGHT / 2
};

interface GameStateStore extends GameState {
  // Game initialization
  initGame: () => void;
  resetGame: () => void;
  
  // Game loop
  updateGame: (deltaTime: number) => void;
  
  // Player controls
  setControls: (controls: Controls) => void;
  movePlayer: (deltaTime: number) => void;
  playerAttack: () => void;
  playerMagicAttack: () => void;
  playerTransform: () => void;
  
  // Enemy management
  spawnEnemy: (type: CharacterType.PASSIVE_ENEMY | CharacterType.AGGRESSIVE_ENEMY, position?: Position) => void;
  spawnNPC: (position?: Position) => void;
  updateEnemies: (deltaTime: number) => void;
  
  // Projectile management
  updateProjectiles: (deltaTime: number) => void;
  
  // Stats and upgrades
  toggleUpgradeMenu: () => void;
  upgradeStat: (stat: keyof Character['stats'], useTP?: boolean) => void;
  updatePlayer: (updatedPlayer: Character, statName?: keyof Character['stats']) => void;
  
  // Race selection
  toggleRaceSelection: () => void;
  selectRace: (race: string, playerClass: string) => void;
  
  // Player name
  setPlayerName: (name: string) => void;
  
  // Controls state
  controls: Controls;
  
  // Additional utility functions
  getCanvasDimensions: () => { width: number, height: number };
}

export const useGameState = create<GameStateStore>((set, get) => {
  // Função auxiliar para atualizar os stats derivados
  const updateDerivedStats = (character: Character, statName?: keyof Character['stats']): Character => {
    const updatedCharacter = { ...character };
    
    // Se não tiver statName, retorna o personagem sem alterações
    if (!statName) {
      return updatedCharacter;
    }
    
    // Atualiza stats derivados com base no atributo modificado
    switch (statName) {
      case 'constitution':
        updatedCharacter.stats.maxHealth = 20 * updatedCharacter.stats.constitution;
        updatedCharacter.stats.health = updatedCharacter.stats.maxHealth;
        // Atualiza também a resistência que vem de constituição
        updatedCharacter.resistance = 5 + (updatedCharacter.stats.constitution * 0.5) + (updatedCharacter.stats.dexterity * 0.5);
        break;
      case 'spirit':
        updatedCharacter.stats.maxKi = 20 * updatedCharacter.stats.spirit;
        updatedCharacter.stats.ki = updatedCharacter.stats.maxKi;
        break;
      case 'dexterity':
        updatedCharacter.stats.maxStamina = 100 + (updatedCharacter.stats.dexterity * 5);
        updatedCharacter.stats.stamina = updatedCharacter.stats.maxStamina;
        // Atualiza velocidade e resistência que vêm de destreza
        updatedCharacter.speed = 2 + (updatedCharacter.stats.dexterity * 0.2);
        updatedCharacter.resistance = 5 + (updatedCharacter.stats.constitution * 0.5) + (updatedCharacter.stats.dexterity * 0.5);
        break;
      case 'strength':
        // Atualiza dano de ataque físico
        updatedCharacter.damage = 10 + (updatedCharacter.stats.strength * 2);
        break;
      case 'willpower':
        // Atualiza dano de ataque de ki
        updatedCharacter.kiDamage = 15 + (updatedCharacter.stats.willpower * 2);
        break;
    }
    
    return updatedCharacter;
  };

  // Generate random position away from player and not colliding with other entities
  const getRandomPosition = (): Position => {
    // Get a position that's significantly far away from the player (fora do campo de visão)
    // Pegamos a posição atual do jogador (ou a inicial, se não estiver disponível)
    const playerPos = get().player?.position || INITIAL_PLAYER_POSITION;
    const state = get();
    const existingEntities = [...state.enemies, ...state.npcs, state.player].filter(Boolean);
    
    // Definir um alcance de visão maior (500-800 pixels de distância)
    const minDistance = 500; // Distância mínima do jogador (fora da visão)
    const maxDistance = 800; // Não tão longe para ainda estar acessível
    
    let position: Position;
    let distance = 0;
    let isColliding = false;
    let attempts = 0;
    const maxAttempts = 20; // Limite de tentativas para evitar loops infinitos
    
    do {
      attempts++;
      isColliding = false;
      
      // Gerar posição aleatória nas bordas da tela ou além
      // Escolher um dos quatro lados da tela para spawn
      const side = Math.floor(Math.random() * 4); // 0=cima, 1=direita, 2=baixo, 3=esquerda
      
      switch(side) {
        case 0: // Topo
          position = {
            x: Math.random() * CANVAS_WIDTH,
            y: -50 + Math.random() * 50 // Ligeiramente acima da tela
          };
          break;
        case 1: // Direita
          position = {
            x: CANVAS_WIDTH + Math.random() * 50, // Ligeiramente à direita da tela
            y: Math.random() * CANVAS_HEIGHT
          };
          break;
        case 2: // Baixo
          position = {
            x: Math.random() * CANVAS_WIDTH,
            y: CANVAS_HEIGHT + Math.random() * 50 // Ligeiramente abaixo da tela
          };
          break;
        case 3: // Esquerda
          position = {
            x: -50 + Math.random() * 50, // Ligeiramente à esquerda da tela
            y: Math.random() * CANVAS_HEIGHT
          };
          break;
        default:
          position = {
            x: Math.random() * CANVAS_WIDTH,
            y: Math.random() * CANVAS_HEIGHT
          };
      }
      
      // Calcular distância até o jogador
      distance = Math.sqrt(
        Math.pow(position.x - playerPos.x, 2) +
        Math.pow(position.y - playerPos.y, 2)
      );
      
      // Se a posição gerada estiver muito fora da tela, tentar novamente
      const tooFarOffScreen = 
        position.x < -200 || position.x > CANVAS_WIDTH + 200 ||
        position.y < -200 || position.y > CANVAS_HEIGHT + 200;
      
      // Verificar colisão com outras entidades (inimigos, NPCs, jogador)
      // Definir um tamanho padrão para a nova entidade a ser criada
      const newEntitySize = { width: 30, height: 30 };
      
      for (const entity of existingEntities) {
        if (!entity) continue;
        
        // Calcular distância entre os centros das entidades
        const entityCenterX = entity.position.x + entity.size.width / 2;
        const entityCenterY = entity.position.y + entity.size.height / 2;
        const newEntityCenterX = position.x + newEntitySize.width / 2;
        const newEntityCenterY = position.y + newEntitySize.height / 2;
        
        const dx = entityCenterX - newEntityCenterX;
        const dy = entityCenterY - newEntityCenterY;
        const distanceToEntity = Math.sqrt(dx * dx + dy * dy);
        
        // Buffer de segurança: soma das metades das larguras e alturas + 10 pixels de margem
        const minSafeDistance = 
          (entity.size.width / 2 + newEntitySize.width / 2) +
          (entity.size.height / 2 + newEntitySize.height / 2) + 
          10;
        
        if (distanceToEntity < minSafeDistance) {
          isColliding = true;
          break;
        }
      }
        
      // Continuar tentando se:
      // 1. A posição estiver muito próxima ou muito longe do jogador, ou
      // 2. A posição estiver colidindo com outra entidade, ou
      // 3. A posição estiver muito fora da tela
      // Mas não tente mais que maxAttempts vezes para evitar loops infinitos
    } while ((distance < minDistance || distance > maxDistance || isColliding) && attempts < maxAttempts);
    
    // Se depois de várias tentativas ainda não encontramos uma posição adequada,
    // apenas usamos a última posição gerada mas com um deslocamento aleatório para evitar sobreposição
    if (attempts >= maxAttempts && isColliding) {
      position.x += (Math.random() * 100) - 50;
      position.y += (Math.random() * 100) - 50;
    }
    
    return position;
  };
  
  // Initialize a player character
  const createInitialPlayer = (): Character => {
    const player = createCharacter(
      CharacterType.PLAYER,
      { ...INITIAL_PLAYER_POSITION },
      'blue'
    );
    
    // Corrigir os atributos iniciais para começar todos com 5
    player.stats.strength = 5;
    player.stats.constitution = 5;
    player.stats.dexterity = 5;
    player.stats.willpower = 5;
    player.stats.spirit = 5;
    
    // Ajustar máximo de vida e ki
    player.stats.maxHealth = 20 * player.stats.constitution;
    player.stats.health = player.stats.maxHealth;
    player.stats.maxKi = 20 * player.stats.spirit;
    player.stats.ki = player.stats.maxKi;
    
    return player;
  };
  
  // Create initial game state
  const initialState: GameState = {
    player: createInitialPlayer(),
    enemies: [],
    npcs: [],
    projectiles: [],
    isGameRunning: false,
    isUpgradeMenuOpen: false,
    isGameOver: false,
    isRaceSelectionOpen: true, // Inicialmente aberto
    isTransformationMenuOpen: false,
    isTechniquesMenuOpen: false,
    isDialogueOpen: false, // Caixa de diálogo fechada inicialmente 
    isMissionMenuOpen: false, // Menu de missões fechado inicialmente
    selectedRace: null,
    playerName: null, // Nome do jogador ainda não definido
    temporaryDamageTexts: [],
    missions: [], // Missões disponíveis (serão carregadas do QuestStore)
    activeMissions: [], // Missões ativas
    completedMissions: [], // Missões completadas
    onlinePlayers: [], // Jogadores online
    kills: 0,
    timeElapsed: 0
  };
  
  return {
    ...initialState,
    controls: {
      up: false,
      down: false,
      left: false,
      right: false,
      attack: false,
      magic: false,
      transform: false
    },
    
    // Initialize game
    initGame: () => {
      const player = createInitialPlayer();
      
      // Spawn initial enemies and NPCs
      const initialEnemies: Character[] = [];
      const initialNpcs: Character[] = [];
      
      // Inicializar o sistema de missões
      const questStore = useQuestStore.getState();
      questStore.initQuests();
      
      // Gerar vários inimigos iniciais (4-6)
      const initialEnemyCount = Math.floor(Math.random() * 3) + 4; // 4-6 inimigos
      
      for (let i = 0; i < initialEnemyCount; i++) {
        initialEnemies.push(
          createCharacter(
            CharacterType.PASSIVE_ENEMY,
            getRandomPosition(),
            'green'
          )
        );
      }
      
      // Sempre criar pelo menos um NPC para missões
      const missionNPC = createCharacter(
        CharacterType.NPC,
        getRandomPosition(),
        'purple'
      );
      
      // Configurar o NPC para ter missões
      missionNPC.hasMission = true;
      missionNPC.missionId = 'quest-001'; // Missão inicial
      
      // Associar a missão ao NPC no sistema de missões
      questStore.assignMissionToNPC(missionNPC.id, 'quest-001');
      initialNpcs.push(missionNPC);
      
      // 50% de chance de gerar um NPC adicional
      if (Math.random() < 0.5) {
        const additionalNPC = createCharacter(
          CharacterType.NPC,
          getRandomPosition(),
          'blue'
        );
        
        // 50% de chance deste NPC também ter uma missão
        if (Math.random() < 0.5) {
          additionalNPC.hasMission = true;
          additionalNPC.missionId = 'quest-002';
          questStore.assignMissionToNPC(additionalNPC.id, 'quest-002');
        }
        
        initialNpcs.push(additionalNPC);
      }
      
      // Se ainda não tiver selecionado uma raça, abrir menu de raça
      const isRaceSelected = get().selectedRace !== null;
      const playerName = get().playerName;
      
      // Obter as missões disponíveis
      const availableMissions = questStore.missions;
      
      set({
        player,
        enemies: initialEnemies,
        npcs: initialNpcs,
        projectiles: [],
        isGameRunning: isRaceSelected && playerName !== null, // Só inicia se tiver raça e nome
        isUpgradeMenuOpen: false,
        isGameOver: false,
        isRaceSelectionOpen: !isRaceSelected || playerName === null, // Abre a seleção se não tiver raça ou nome
        isTransformationMenuOpen: false,
        isTechniquesMenuOpen: false,
        isDialogueOpen: false,
        isMissionMenuOpen: false,
        temporaryDamageTexts: [],
        missions: availableMissions,
        activeMissions: [],
        completedMissions: [],
        onlinePlayers: [],
        kills: 0,
        timeElapsed: 0
      });
    },
    
    // Reset game state
    resetGame: () => {
      set({
        ...initialState,
        player: createInitialPlayer(),
        isGameRunning: false,
        isRaceSelectionOpen: true
      });
    },
    
    // Define o nome do jogador
    setPlayerName: (name: string) => {
      const { player } = get();
      set({ 
        playerName: name,
        player: {
          ...player,
          name: name
        }
      });
    },
    
    // Transform the player if they have enough TP
    playerTransform: () => {
      const { player } = get();
      
      // Use the utility function to handle transformation
      const transformedPlayer = applyTransformation(player);
      
      // If player has transformed (different than before)
      if (transformedPlayer.stats.transformationLevel !== player.stats.transformationLevel) {
        // Play transformation sound
        const audioStore = useAudio.getState();
        audioStore.playPowerup();
        
        // Update player state
        set({ player: transformedPlayer });
      }
    },
    
    // Update game state (main game loop)
    updateGame: (deltaTime) => {
      const state = get();
      
      if (!state.isGameRunning || state.isGameOver) {
        return;
      }
      
      // Skip game updates if upgrade menu is open
      if (state.isUpgradeMenuOpen) {
        return;
      }
      
      // Check for transformation control
      if (state.controls.transform) {
        state.playerTransform();
        // Reset transform control to prevent multiple transformations
        set({
          controls: {
            ...state.controls,
            transform: false
          }
        });
      }
      
      // Update player position based on controls
      state.movePlayer(deltaTime);
      
      // Update enemies
      state.updateEnemies(deltaTime);
      
      // Update projectiles
      state.updateProjectiles(deltaTime);
      
      // Regenerate stamina when not attacking (1 per frame up to max)
      const { player, enemies } = state;
      if (player.stats.stamina < player.stats.maxStamina && !player.isAttacking) {
        set({
          player: {
            ...player,
            stats: {
              ...player.stats,
              stamina: Math.min(player.stats.maxStamina, player.stats.stamina + 0.5)
            }
          }
        });
      }
      
      // Gerenciar spawn de inimigos - em grupos de 2-5 inimigos
      // Se não há inimigos, cria um novo grupo
      if (enemies.length === 0) {
        state.spawnEnemy(CharacterType.PASSIVE_ENEMY);
      }
      
      // Manter uma quantidade mínima de inimigos (5-10)
      // Assim temos mais inimigos na tela e mais ação
      const minEnemyCount = 5;
      const maxEnemyCount = 10;
      const currentEnemyCount = enemies.length;
      
      // Se temos menos que o mínimo de inimigos, spawn um novo grupo
      if (currentEnemyCount < minEnemyCount && Math.random() < 0.02) { // 2% de chance por frame
        state.spawnEnemy(CharacterType.PASSIVE_ENEMY);
      }
      
      // Remover inimigos inativos (que não foram provocados) após 30 segundos
      // e estão BEM LONGE do jogador (fora do alcance de visão)
      const now = Date.now();
      const inactiveEnemies = enemies.filter(enemy => {
        if (enemy.isProvoked) return false; // Manter inimigos provocados
        
        // Calcular distância ao jogador
        const dx = player.position.x - enemy.position.x;
        const dy = player.position.y - enemy.position.y;
        const distToPlayer = Math.sqrt(dx * dx + dy * dy);
        
        // Verificar se o inimigo está muito fora da tela
        const isFarOffScreen = 
          enemy.position.x < -100 || enemy.position.x > CANVAS_WIDTH + 100 ||
          enemy.position.y < -100 || enemy.position.y > CANVAS_HEIGHT + 100;
        
        // Se o inimigo está muito longe (fora do campo de visão) e existe há mais de 30 segundos, remover
        const enemyAge = now - (enemy.createdAt || 0); // Tempo de vida do inimigo
        const visionRange = 600; // Alcance de visão mais amplo (pixels)
        
        // Só remove inimigos que estão realmente longe (fora da visão) e inativos por um tempo
        return (distToPlayer > visionRange || isFarOffScreen) && enemyAge > 30000;
      });
      
      // Remover inimigos inativos
      if (inactiveEnemies.length > 0) {
        set({
          enemies: enemies.filter(e => !inactiveEnemies.some(ie => ie.id === e.id))
        });
        
        // Se removeu inimigos inativos e ficamos com menos que o mínimo, spawnar novo grupo
        if (enemies.length - inactiveEnemies.length < minEnemyCount) {
          state.spawnEnemy(CharacterType.PASSIVE_ENEMY);
        }
      }
      
      // Se passamos do máximo de inimigos, não spawn mais
      if (currentEnemyCount > maxEnemyCount) {
        // Limita a quantidade máxima de inimigos para não sobrecarregar o jogo
        // Remove os mais antigos se necessário
        if (currentEnemyCount > maxEnemyCount + 3) {
          const sortedEnemies = [...enemies].sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
          const enemiesToRemove = sortedEnemies.slice(0, currentEnemyCount - maxEnemyCount);
          
          set({
            enemies: enemies.filter(e => !enemiesToRemove.some(re => re.id === e.id))
          });
        }
      }
      
      // Handle transformation KI drain
      if (player.stats.transformationLevel > 0 && player.stats.ki > 0) {
        const kiDrain = player.stats.transformationLevel; // 1 por segundo para nível 1, 2 por segundo para nível 2
        
        // Drain KI based on transformation level
        const updatedKi = Math.max(0, player.stats.ki - (kiDrain * 0.02)); // Ajustado para 60 FPS
        
        // If KI reaches 0, revert back to base form
        if (updatedKi <= 0) {
          // Revert transformation
          set({
            player: {
              ...player,
              stats: {
                ...player.stats,
                ki: 0,
                transformationLevel: 0,
                // Reset multipliers when reverting
                strength: Math.floor(player.stats.strength / getTransformationMultiplier(player.stats.transformationLevel)),
                constitution: Math.floor(player.stats.constitution / getTransformationMultiplier(player.stats.transformationLevel)),
                dexterity: Math.floor(player.stats.dexterity / getTransformationMultiplier(player.stats.transformationLevel)),
                willpower: Math.floor(player.stats.willpower / getTransformationMultiplier(player.stats.transformationLevel)),
                spirit: Math.floor(player.stats.spirit / getTransformationMultiplier(player.stats.transformationLevel))
              }
            }
          });
        } else {
          // Just update KI
          set({
            player: {
              ...player,
              stats: {
                ...player.stats,
                ki: updatedKi
              }
            }
          });
        }
      }
      
      // Check if player is dead
      if (state.player.stats.health <= 0) {
        set({ isGameOver: true, isGameRunning: false });
      }
    },
    
    // Set control state
    setControls: (controls) => {
      set({ controls });
    },
    
    // Move player based on controls
    movePlayer: (deltaTime) => {
      const { player, controls, enemies, npcs } = get();
      
      // Calculate movement based on controls
      const movementSpeed = 3 + (player.stats.dexterity * 0.1);
      
      // Calculate velocity based on controls
      const velocity = { x: 0, y: 0 };
      
      if (controls.up) velocity.y = -movementSpeed;
      if (controls.down) velocity.y = movementSpeed;
      if (controls.left) velocity.x = -movementSpeed;
      if (controls.right) velocity.x = movementSpeed;
      
      // Diagonal movement should not be faster
      if (velocity.x !== 0 && velocity.y !== 0) {
        velocity.x /= Math.sqrt(2);
        velocity.y /= Math.sqrt(2);
      }
      
      // Calculate new position
      let newPosition = { 
        x: player.position.x + velocity.x, 
        y: player.position.y + velocity.y 
      };
      
      // Check if new position is in bounds
      if (!isInBounds(newPosition, player.size, CANVAS_WIDTH, CANVAS_HEIGHT)) {
        // Adjust position to stay in bounds
        newPosition.x = Math.max(0, Math.min(CANVAS_WIDTH - player.size.width, newPosition.x));
        newPosition.y = Math.max(0, Math.min(CANVAS_HEIGHT - player.size.height, newPosition.y));
      }
      
      // Check for collisions with enemies and NPCs
      const obstacles = [...enemies, ...npcs];
      newPosition = resolveCollision(player.position, player.size, velocity, obstacles);
      
      // Update player position and velocity
      set({
        player: {
          ...player,
          position: newPosition,
          velocity
        }
      });
    },
    
    // Player attack
    playerAttack: () => {
      const state = get();
      const { player } = state;
      
      // Check attack cooldown
      if (!canAttack(player, ATTACK_COOLDOWN)) {
        return;
      }
      
      // Consome estamina aleatoriamente entre 1-5 pontos por ataque
      const staminaCost = Math.floor(Math.random() * 5) + 1;
      if (player.stats.stamina < staminaCost) {
        return; // Não tem estamina suficiente para atacar
      }
      
      // Play attack sound
      const audioStore = useAudio.getState();
      audioStore.playHit();
      
      // Set player to attacking state, update last attack time e consome stamina
      const updatedPlayer = {
        ...player,
        isAttacking: true,
        lastAttackTime: Date.now(),
        stats: {
          ...player.stats,
          stamina: player.stats.stamina - staminaCost
        }
      };
      
      set({ player: updatedPlayer });
      
      // Create a timer to reset attack state
      setTimeout(() => {
        const currentPlayer = get().player;
        set({
          player: {
            ...currentPlayer,
            isAttacking: false
          }
        });
        
        // Check for enemies in attack range
        const { enemies, npcs } = get();
        const attackRange = 60; // Melee attack range (aumentado de 40 para 60)
        
        // Combine enemies and NPCs to check for attacks
        const targets = [...enemies, ...npcs];
        
        for (const target of targets) {
          // Calculate distance between player and target
          const dx = target.position.x - currentPlayer.position.x;
          const dy = target.position.y - currentPlayer.position.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance <= attackRange) {
            // Calculate damage
            const damage = calculateDamage(currentPlayer, target);
            
            // Apply damage to target
            const isDead = applyDamage(target, damage);
            
            // Ganhar 1 TP por ataque bem sucedido
            const updatedPlayer = {
              ...currentPlayer,
              stats: {
                ...currentPlayer.stats,
                transformationPoints: currentPlayer.stats.transformationPoints + 1
              }
            };
            set({ player: updatedPlayer });
            
            // If target is an NPC or a passive enemy, provoke it
            if (target.type === CharacterType.NPC || target.type === CharacterType.PASSIVE_ENEMY) {
              target.isProvoked = true;
            }
            
            // If target died
            if (isDead) {
              // Handle enemy death
              if (target.type !== CharacterType.NPC) {
                // Award experience to player
                const updatedPlayer = awardExperience(currentPlayer, 20);
                set({ 
                  player: updatedPlayer,
                  kills: get().kills + 1
                });
                
                // Atualizar objetivos de quests ativas
                const { activeMissions } = get();
                activeMissions.forEach(quest => {
                  const questStore = useQuestStore.getState();
                  questStore.updateQuestObjective(quest.id, QuestType.KILL_ENEMIES, target.type);
                });
                
                // Remove dead enemy
                const updatedEnemies = get().enemies.filter(e => e.id !== target.id);
                set({ enemies: updatedEnemies });
              } else {
                // Remove dead NPC
                const updatedNpcs = get().npcs.filter(n => n.id !== target.id);
                set({ npcs: updatedNpcs });
              }
            } else {
              // Update the damaged target
              if (target.type !== CharacterType.NPC) {
                const updatedEnemies = get().enemies.map(e => 
                  e.id === target.id ? target : e
                );
                set({ enemies: updatedEnemies });
              } else {
                const updatedNpcs = get().npcs.map(n => 
                  n.id === target.id ? target : n
                );
                set({ npcs: updatedNpcs });
              }
            }
          }
        }
      }, 200);
    },
    
    // Player magic attack (ranged)
    playerMagicAttack: () => {
      const state = get();
      const { player, controls } = state;
      
      // Check if player has enough ki
      const kiCost = 10;
      if (player.stats.ki < kiCost) {
        return;
      }
      
      // Check cooldown
      if (!canAttack(player, MAGIC_COOLDOWN)) {
        return;
      }
      
      // Calculate direction based on controls or find nearest enemy
      let direction = { x: 0, y: 0 };
      
      if (controls.up) direction.y = -1;
      if (controls.down) direction.y = 1;
      if (controls.left) direction.x = -1;
      if (controls.right) direction.x = 1;
      
      // If no direction specified, target nearest enemy
      if (direction.x === 0 && direction.y === 0) {
        const { enemies, npcs } = state;
        const targets = [...enemies, ...npcs].filter(e => e.stats.health > 0);
        
        if (targets.length > 0) {
          // Find nearest target
          let nearestTarget = targets[0];
          let minDistance = Number.MAX_VALUE;
          
          targets.forEach(target => {
            const dx = target.position.x - player.position.x;
            const dy = target.position.y - player.position.y;
            const distance = Math.sqrt(dx * dx + dy * dy);
            
            if (distance < minDistance) {
              minDistance = distance;
              nearestTarget = target;
            }
          });
          
          // Calculate direction to nearest target
          const dx = nearestTarget.position.x - player.position.x;
          const dy = nearestTarget.position.y - player.position.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          
          if (distance > 0) {
            direction.x = dx / distance;
            direction.y = dy / distance;
          } else {
            direction.x = 1; // Default right if somehow target is at same position
          }
        } else {
          direction.x = 1; // Default right if no targets
        }
      }
      
      // Play sound
      const audioStore = useAudio.getState();
      audioStore.playSuccess();
      
      // Calculate projectile starting position (center of player)
      const startPos = {
        x: player.position.x + player.size.width / 2 - 5, // Center X - half projectile width
        y: player.position.y + player.size.height / 2 - 5 // Center Y - half projectile height
      };
      
      // Create projectile
      const damage = calculateKiDamage(player);
      const newProjectile = createProjectile(player.id, startPos, direction, damage, 'blue');
      
      // Update player (reduce ki and set last attack time)
      const updatedPlayer = {
        ...player,
        stats: {
          ...player.stats,
          ki: player.stats.ki - kiCost
        },
        lastAttackTime: Date.now()
      };
      
      set({
        player: updatedPlayer,
        projectiles: [...state.projectiles, newProjectile]
      });
    },
    
    // Spawn enemy at a specific or random position
    spawnEnemy: (type, position) => {
      // Gerar vários inimigos de uma vez (2-5 inimigos)
      const passiveType = CharacterType.PASSIVE_ENEMY;
      const color = 'green'; // Cor para inimigos passivos
      
      // Determinar quantidade de inimigos a serem gerados (2-5)
      const enemyCount = Math.floor(Math.random() * 4) + 2; // Gera entre 2 e 5 inimigos
      const newEnemies: Character[] = [];
      
      // Definir uma posição base para o grupo
      const basePosition = position || getRandomPosition();
      
      // Criar os novos inimigos com espaçamento suficiente entre eles
      for (let i = 0; i < enemyCount; i++) {
        // Gerar uma posição para cada inimigo, garantindo que não colide com outros
        let enemyPosition;
        
        // Se uma posição base foi definida, criar posições ao redor dela
        // Caso contrário, gerar posições totalmente aleatórias
        if (position) {
          // Criar posição em torno da base, mas espaçados para evitar colisões
          // Colocar em formação circular ao redor da posição base
          const angle = (i / enemyCount) * Math.PI * 2; // Ângulos distribuídos em círculo
          const distance = 50 + (Math.random() * 30); // Distância do centro (50-80 pixels)
          
          enemyPosition = {
            x: basePosition.x + Math.cos(angle) * distance,
            y: basePosition.y + Math.sin(angle) * distance
          };
        } else {
          // Para cada inimigo após o primeiro, gerar posição nova completamente aleatória
          // getRandomPosition já verifica colisões com outras entidades
          enemyPosition = i === 0 ? basePosition : getRandomPosition();
        }
        
        // Criar o novo inimigo
        const newEnemy = createCharacter(passiveType, enemyPosition, color);
        newEnemies.push(newEnemy);
      }
      
      // Adicionar os novos inimigos ao estado
      set(state => ({
        enemies: [...state.enemies, ...newEnemies]
      }));
    },
    
    // Spawn NPC at a specific or random position
    spawnNPC: (position) => {
      const pos = position || getRandomPosition();
      const newNPC = createCharacter(CharacterType.NPC, pos, 'purple');
      
      set(state => ({
        npcs: [...state.npcs, newNPC]
      }));
    },
    
    // Update all enemies
    updateEnemies: (deltaTime) => {
      const { player, enemies, npcs } = get();
      
      // Update each enemy
      const updatedEnemies = enemies.map(enemy => {
        // Skip if enemy is dead
        if (enemy.stats.health <= 0) return enemy;
        
        // Calculate distance to player
        const dx = player.position.x - enemy.position.x;
        const dy = player.position.y - enemy.position.y;
        const distanceToPlayer = Math.sqrt(dx * dx + dy * dy);
        
        // Calculate direction to player
        const directionToPlayer = {
          x: dx === 0 ? 0 : dx / Math.abs(dx),
          y: dy === 0 ? 0 : dy / Math.abs(dy)
        };
        
        let newVelocity = { x: 0, y: 0 };
        let shouldAttack = false;
        
        // Todos os inimigos seguem o jogador quando estiverem no campo de visão
        const visionRange = 300; // Área de visão aumentada do inimigo
        const meleeAttackRange = 40; // Distância para o ataque corpo a corpo
        const continuousDamageRange = 30; // Distância para aplicar dano contínuo

        // Verifica se o jogador está dentro da área de visão
        const isPlayerInRange = distanceToPlayer < visionRange;
        const isPlayerInMeleeRange = distanceToPlayer < meleeAttackRange;
        const isPlayerInContinuousDamageRange = distanceToPlayer < continuousDamageRange;
        
        // Se o jogador entrar na área, o inimigo fica provocado
        if (isPlayerInRange) {
          enemy.isProvoked = true;
        }
        
        // Se o inimigo estiver provocado e o jogador estiver na área de detecção
        if (enemy.isProvoked && isPlayerInRange) {
          // Move em direção ao jogador
          newVelocity = {
            x: directionToPlayer.x * 1.5,
            y: directionToPlayer.y * 1.5
          };
          
          // Ataca se estiver próximo o suficiente
          shouldAttack = isPlayerInMeleeRange && canAttack(enemy, ENEMY_ATTACK_COOLDOWN);
          
          // Dano contínuo quando em alcance corpo a corpo
          if (isPlayerInMeleeRange) {
            // Causa dano a cada segundo
            const now = Date.now();
            if (now - (enemy.lastDamageTime || 0) >= 1000) { // 1000ms = 1 segundo
              // Calcula o dano baseado na força do inimigo (1/3 do dano normal de ataque)
              const damagePeriodic = Math.max(1, Math.floor(calculateDamage(enemy, player) / 3));
              
              // Aplica dano ao jogador
              const updatedPlayer = { ...player };
              applyDamage(updatedPlayer, damagePeriodic);
              
              // Cria um texto de dano
              const damageTextId = generateId();
              const damageText: DamageText = {
                id: damageTextId,
                position: { ...player.position },
                value: damagePeriodic,
                color: 'red',
                createdAt: Date.now(),
                type: 'damage',
                velocity: { x: 0, y: -0.5 } // Movimento suave para cima
              };
              
              // Atualiza o jogador e adiciona o texto de dano
              set(state => ({
                player: updatedPlayer,
                temporaryDamageTexts: [...state.temporaryDamageTexts, damageText]
              }));
              
              // Atualiza o último tempo de dano do inimigo
              enemy.lastDamageTime = now;
            }
          }
        } 
        // Se o jogador sair da área, o inimigo para de perseguir
        else if (enemy.isProvoked && !isPlayerInRange) {
          enemy.isProvoked = false;
          newVelocity = { x: 0, y: 0 }; // Para de se mover
        }
        // Comportamento normal quando não está perseguindo o jogador
        else {
          // Comportamento de perambulação aleatória
          if (Math.random() < 0.01) { // Ocasionalmente muda de direção
            newVelocity = {
              x: (Math.random() - 0.5) * 2,
              y: (Math.random() - 0.5) * 2
            };
          } else {
            newVelocity = { ...enemy.velocity };
          }
        }
        
        // Calculate new position
        let newPosition = {
          x: enemy.position.x + newVelocity.x,
          y: enemy.position.y + newVelocity.y
        };
        
        // Keep within bounds
        if (!isInBounds(newPosition, enemy.size, CANVAS_WIDTH, CANVAS_HEIGHT)) {
          newPosition.x = Math.max(0, Math.min(CANVAS_WIDTH - enemy.size.width, newPosition.x));
          newPosition.y = Math.max(0, Math.min(CANVAS_HEIGHT - enemy.size.height, newPosition.y));
          
          // Reverse direction if hit boundary
          newVelocity.x = -newVelocity.x * 0.5;
          newVelocity.y = -newVelocity.y * 0.5;
        }
        
        // Check for collisions with other enemies
        const obstacles = [...enemies.filter(e => e.id !== enemy.id), ...npcs, player];
        newPosition = resolveCollision(enemy.position, enemy.size, newVelocity, obstacles);
        
        // Return updated enemy
        return {
          ...enemy,
          position: newPosition,
          velocity: newVelocity,
          isAttacking: shouldAttack
        };
      });
      
      // Update NPCs
      const updatedNPCs = npcs.map(npc => {
        // Skip if NPC is dead
        if (npc.stats.health <= 0) return npc;
        
        let newVelocity = { x: 0, y: 0 };
        let newPosition = { ...npc.position };
        let shouldAttack = false;
        
        // If provoked, go after the player
        if (npc.isProvoked) {
          // Calculate distance to player
          const dx = player.position.x - npc.position.x;
          const dy = player.position.y - npc.position.y;
          const distanceToPlayer = Math.sqrt(dx * dx + dy * dy);
          
          // Calculate direction to player
          const directionToPlayer = {
            x: dx === 0 ? 0 : dx / Math.abs(dx),
            y: dy === 0 ? 0 : dy / Math.abs(dy)
          };
          
          // Move towards player if not too close
          if (distanceToPlayer > 40) {
            newVelocity = {
              x: directionToPlayer.x * 2,
              y: directionToPlayer.y * 2
            };
          }
          
          // Attack if in range
          shouldAttack = distanceToPlayer < 40 && canAttack(npc, ENEMY_ATTACK_COOLDOWN);
          
          if (shouldAttack) {
            // Calculate damage
            const damage = calculateDamage(npc, player);
            
            // Apply damage to player
            const updatedPlayer = { ...player };
            applyDamage(updatedPlayer, damage);
            
            // Update player
            set({ player: updatedPlayer });
            
            // Update NPC's last attack time
            npc.lastAttackTime = Date.now();
          }
        } else {
          // Random wandering behavior
          if (Math.random() < 0.005) { // Occasionally change direction
            newVelocity = {
              x: (Math.random() - 0.5) * 1.5,
              y: (Math.random() - 0.5) * 1.5
            };
          } else {
            newVelocity = { ...npc.velocity };
          }
        }
        
        // Calculate new position
        newPosition = {
          x: npc.position.x + newVelocity.x,
          y: npc.position.y + newVelocity.y
        };
        
        // Keep within bounds
        if (!isInBounds(newPosition, npc.size, CANVAS_WIDTH, CANVAS_HEIGHT)) {
          newPosition.x = Math.max(0, Math.min(CANVAS_WIDTH - npc.size.width, newPosition.x));
          newPosition.y = Math.max(0, Math.min(CANVAS_HEIGHT - npc.size.height, newPosition.y));
          
          // Reverse direction if hit boundary
          newVelocity.x = -newVelocity.x * 0.5;
          newVelocity.y = -newVelocity.y * 0.5;
        }
        
        // Check for collisions with enemies and other NPCs
        const obstacles = [...enemies, ...npcs.filter(n => n.id !== npc.id), player];
        newPosition = resolveCollision(npc.position, npc.size, newVelocity, obstacles);
        
        // Return updated NPC
        return {
          ...npc,
          position: newPosition,
          velocity: newVelocity,
          isAttacking: shouldAttack
        };
      });
      
      set({
        enemies: updatedEnemies,
        npcs: updatedNPCs
      });
    },
    
    // Update projectiles
    updateProjectiles: (deltaTime) => {
      const { projectiles, player, enemies, npcs } = get();
      
      // Update positions and check collisions
      const updatedProjectiles = projectiles.filter(projectile => {
        // Move projectile
        const newPosition = {
          x: projectile.position.x + projectile.velocity.x,
          y: projectile.position.y + projectile.velocity.y
        };
        
        // Update position
        projectile.position = newPosition;
        
        // Check if out of bounds
        if (!isInBounds(newPosition, projectile.size, CANVAS_WIDTH, CANVAS_HEIGHT)) {
          return false; // Remove projectile
        }
        
        // Check for collisions with characters
        let hitCharacter: Character | null = null;
        
        // If projectile is from player, check against enemies and NPCs
        if (projectile.ownerId === player.id) {
          // Check enemies
          hitCharacter = checkProjectileCollision(projectile, enemies);
          
          if (!hitCharacter) {
            // Check NPCs
            hitCharacter = checkProjectileCollision(projectile, npcs);
          }
          
          if (hitCharacter) {
            // Apply damage
            const isDead = applyDamage(hitCharacter, projectile.damage);
            
            // Ganhar 1 TP por ataque de ki bem sucedido
            const updatedPlayer = {
              ...player,
              stats: {
                ...player.stats,
                transformationPoints: player.stats.transformationPoints + 1
              }
            };
            set({ player: updatedPlayer });
            
            // If it's an NPC or passive enemy, provoke it
            if (hitCharacter.type === CharacterType.NPC || hitCharacter.type === CharacterType.PASSIVE_ENEMY) {
              hitCharacter.isProvoked = true;
            }
            
            // If target died
            if (isDead) {
              // Handle enemy death
              if (hitCharacter.type !== CharacterType.NPC) {
                // Award experience to player
                const updatedPlayer = awardExperience(player, 20);
                set({ 
                  player: updatedPlayer,
                  kills: get().kills + 1,
                  enemies: enemies.filter(e => e.id !== hitCharacter?.id)
                });
                
                // Atualizar objetivos de quests ativas
                const { activeMissions } = get();
                activeMissions.forEach(quest => {
                  const questStore = useQuestStore.getState();
                  if (hitCharacter) {
                    questStore.updateQuestObjective(quest.id, QuestType.KILL_ENEMIES, hitCharacter.type);
                  }
                });
              } else {
                // Remove dead NPC
                set({ 
                  npcs: npcs.filter(n => n.id !== hitCharacter?.id)
                });
              }
            } else {
              // Update the damaged character
              if (hitCharacter.type !== CharacterType.NPC) {
                set({
                  enemies: enemies.map(e => e.id === hitCharacter?.id ? hitCharacter : e)
                });
              } else {
                set({
                  npcs: npcs.map(n => n.id === hitCharacter?.id ? hitCharacter : n)
                });
              }
            }
            
            return false; // Remove projectile after hit
          }
        } 
        // If projectile is from enemy, check against player
        else {
          // Check if projectile hits player
          if (checkCollision(projectile.position, projectile.size, player.position, player.size)) {
            // Apply damage to player
            const updatedPlayer = { ...player };
            applyDamage(updatedPlayer, projectile.damage);
            
            // Update player
            set({ player: updatedPlayer });
            
            return false; // Remove projectile after hit
          }
        }
        
        return true; // Keep projectile
      });
      
      set({ projectiles: updatedProjectiles });
    },
    
    // Toggle the upgrade menu
    toggleUpgradeMenu: () => {
      set(state => ({ isUpgradeMenuOpen: !state.isUpgradeMenuOpen }));
    },
    
    // Upgrade a stat
    upgradeStat: (statName, useTP = false) => {
      const { player, selectedRace } = get();
      
      if (useTP) {
        // Se usar TP, verifica se tem pontos de transformação suficientes
        // O custo base é 15 + (nível atual - nível base) por cada upgrade
        const baseValue = selectedRace === 'human' ? 5 : 
                         selectedRace === 'saiyan' && statName === 'strength' ? 8 :
                         selectedRace === 'saiyan' && statName === 'constitution' ? 6 :
                         selectedRace === 'saiyan' && statName === 'dexterity' ? 4 :
                         selectedRace === 'saiyan' && statName === 'willpower' ? 3 :
                         selectedRace === 'saiyan' && statName === 'spirit' ? 4 :
                         selectedRace === 'arcosian' && statName === 'strength' ? 3 :
                         selectedRace === 'arcosian' && statName === 'constitution' ? 7 :
                         selectedRace === 'arcosian' && statName === 'dexterity' ? 7 :
                         selectedRace === 'arcosian' && statName === 'willpower' ? 4 :
                         selectedRace === 'arcosian' && statName === 'spirit' ? 4 :
                         selectedRace === 'namekian' && statName === 'strength' ? 6 :
                         selectedRace === 'namekian' && statName === 'constitution' ? 6 :
                         selectedRace === 'namekian' && statName === 'dexterity' ? 4 :
                         selectedRace === 'namekian' && statName === 'willpower' ? 3 :
                         selectedRace === 'namekian' && statName === 'spirit' ? 6 : 5;
                         
        const currentLevel = player.stats[statName];
        const cost = 15 + (currentLevel - baseValue);
        
        if (player.stats.transformationPoints < cost) {
          return;
        }
        
        // Atualiza os TP e o atributo
        const updatedPlayer = {
          ...player,
          stats: {
            ...player.stats,
            [statName]: player.stats[statName] + 1,
            transformationPoints: player.stats.transformationPoints - cost
          }
        };
        
        // Atualiza os stats derivados
        set({ player: updateDerivedStats(updatedPlayer, statName) });
      } else {
        // Check if player has stat points
        if (player.stats.statPoints <= 0) {
          return;
        }
        
        // Apply the stat upgrade
        const updatedPlayer = applyStatUpgrade(player, statName);
        set({ player: updatedPlayer });
      }
    },
    
    // Get canvas dimensions
    // Toggle race selection menu
    toggleRaceSelection: () => {
      set(state => ({
        isRaceSelectionOpen: !state.isRaceSelectionOpen
      }));
    },
    
    // Select race and class for the player
    selectRace: (race: string, playerClass: string) => {
      // Update player stats based on race
      const { player } = get();
      let baseStats = { ...player.stats };
      let playerColor = '#FFFFFF'; // Cor padrão branca
      
      // Adjust base stats based on selected race
      // Human (5/5/5/5/5)
      // Saiyan (8/6/4/3/4)
      // Arcosian (3/7/7/4/4)
      // Namekian (6/6/4/3/6)
      switch(race) {
        case 'human':
          baseStats.strength = 5;
          baseStats.constitution = 5;
          baseStats.dexterity = 5;
          baseStats.willpower = 5;
          baseStats.spirit = 5;
          playerColor = '#FFD3BD'; // Cor de pele humana
          break;
        case 'saiyan':
          baseStats.strength = 8;
          baseStats.constitution = 6;
          baseStats.dexterity = 4;
          baseStats.willpower = 3;
          baseStats.spirit = 4;
          playerColor = '#FFB142'; // Cor dourada (referência a Super Saiyan)
          break;
        case 'arcosian':
          baseStats.strength = 3;
          baseStats.constitution = 7;
          baseStats.dexterity = 7;
          baseStats.willpower = 4;
          baseStats.spirit = 4;
          playerColor = '#9DB4FF'; // Cor azulada clara (como Frieza)
          break;
        case 'namekian':
          baseStats.strength = 6;
          baseStats.constitution = 6;
          baseStats.dexterity = 4;
          baseStats.willpower = 3;
          baseStats.spirit = 6;
          playerColor = '#7CFC00'; // Verde vibrante para Namekians
          break;
        default:
          // Default to human
          baseStats.strength = 5;
          baseStats.constitution = 5;
          baseStats.dexterity = 5;
          baseStats.willpower = 5;
          baseStats.spirit = 5;
          playerColor = '#FFD3BD';
      }
      
      // Aplicar bônus de classe aos atributos base
      switch(playerClass) {
        case 'warrior':
          // Guerreiro: +3 STR, +3 WIL
          baseStats.strength += 3;
          baseStats.willpower += 3;
          break;
        case 'spiritualist':
          // Espiritualista: +3 SPI, +1 CON, +1 STR, +1 DEX
          baseStats.spirit += 3;
          baseStats.constitution += 1;
          baseStats.strength += 1;
          baseStats.dexterity += 1;
          break;
        case 'tanker':
          // Tanker: +3 CON, +3 DEX
          baseStats.constitution += 3;
          baseStats.dexterity += 3;
          break;
      }
      
      // Recalcular todos os valores baseados nos stats
      // Vida e KI
      baseStats.maxHealth = 20 * baseStats.constitution;
      baseStats.health = baseStats.maxHealth;
      baseStats.maxKi = 20 * baseStats.spirit;
      baseStats.ki = baseStats.maxKi;
      
      // Energia e regeneração
      baseStats.maxStamina = 100 + (baseStats.dexterity * 5);
      baseStats.stamina = baseStats.maxStamina;
      
      // Dano de ataque baseado na força
      const attackDamage = 10 + (baseStats.strength * 2);
      
      // Dano de ataque de KI baseado na força de vontade
      const kiAttackDamage = 15 + (baseStats.willpower * 2);
      
      // Velocidade baseada na destreza
      const speed = 2 + (baseStats.dexterity * 0.2);
      
      // Resistência a dano baseada na constituição e destreza
      const resistance = 5 + (baseStats.constitution * 0.5) + (baseStats.dexterity * 0.5);
      
      // Update player
      set({
        player: {
          ...player,
          stats: baseStats,
          color: playerColor,
          speed: speed,
          damage: attackDamage,
          kiDamage: kiAttackDamage,
          resistance: resistance,
          selectedRace: race,
          selectedClass: playerClass
        },
        selectedRace: race,
        isRaceSelectionOpen: false,
        isGameRunning: true
      });
      
      // Initialize the game after race selection
      setTimeout(() => {
        get().initGame();
      }, 0);
    },
    
    getCanvasDimensions: () => {
      // Obtém as dimensões atuais da janela do navegador
      const dimensions = getWindowDimensions();
      
      // Atualiza as variáveis globais
      CANVAS_WIDTH = dimensions.width;
      CANVAS_HEIGHT = dimensions.height;
      
      return {
        width: CANVAS_WIDTH,
        height: CANVAS_HEIGHT
      };
    },
    
    // Função para atualizar o player e seus stats derivados
    updatePlayer: (updatedPlayer: Character, statName?: keyof Character['stats']) => {
      // Primeiro vamos atualizar os stats derivados
      const playerWithDerivedStats = updateDerivedStats(updatedPlayer, statName);
      
      // Depois atualizamos o jogador no estado global
      set({ player: playerWithDerivedStats });
    }
  };
});
