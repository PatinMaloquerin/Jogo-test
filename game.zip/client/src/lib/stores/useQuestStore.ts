import { create } from 'zustand';
import { 
  Quest, 
  QuestType, 
  QuestStatus, 
  QuestObjective, 
  CharacterType 
} from '../types';
import { generateId } from '../utils';

// Tipos de missões disponíveis
const DEFAULT_QUESTS: Quest[] = [
  {
    id: 'quest-001',
    title: 'Treinamento Inicial',
    description: 'Derrote 5 inimigos para provar sua força e ganhar pontos de transformação.',
    objectives: [
      {
        type: QuestType.KILL_ENEMIES,
        target: CharacterType.PASSIVE_ENEMY,
        required: 5,
        current: 0
      }
    ],
    rewards: {
      tp: 50,
      experience: 100
    },
    isCompleted: false
  },
  {
    id: 'quest-002',
    title: 'Caçador de Recompensas',
    description: 'Elimine 10 inimigos para mostrar seu valor como caçador.',
    objectives: [
      {
        type: QuestType.KILL_ENEMIES,
        target: CharacterType.PASSIVE_ENEMY,
        required: 10,
        current: 0
      }
    ],
    rewards: {
      tp: 100,
      experience: 200
    },
    isCompleted: false
  },
  {
    id: 'quest-003',
    title: 'Treinamento de Ki',
    description: 'Alcance o nível 5 para aprimorar seu controle de Ki.',
    objectives: [
      {
        type: QuestType.REACH_LEVEL,
        target: 'level',
        required: 5,
        current: 1
      }
    ],
    rewards: {
      tp: 150,
      experience: 0
    },
    isCompleted: false
  },
  {
    id: 'quest-004',
    title: 'Primeira Transformação',
    description: 'Alcance sua primeira transformação para desbloquear novos poderes.',
    objectives: [
      {
        type: QuestType.REACH_TRANSFORMATION,
        target: 'transformation',
        required: 1,
        current: 0
      }
    ],
    rewards: {
      tp: 200,
      experience: 300
    },
    isCompleted: false
  }
];

// Interface da store de missões
interface QuestStore {
  // Estado
  missions: Quest[];
  activeMissions: Quest[];
  completedMissions: Quest[];
  currentMission: Quest | null;
  availableNPCMissions: Map<string, string[]>; // Map de NPCid -> array de missionIds

  // Ações
  initQuests: () => void;
  getMissionsForNPC: (npcId: string) => Quest[];
  getQuestById: (questId: string) => Quest | undefined;
  getQuestStatus: (questId: string) => QuestStatus;
  acceptQuest: (questId: string) => void;
  completeQuest: (questId: string) => boolean;
  updateQuestObjective: (questId: string, type: QuestType, target: string | CharacterType, amount?: number) => void;
  setCurrentMission: (mission: Quest | null) => void;
  assignMissionToNPC: (npcId: string, missionId: string) => void;
  isQuestCompleted: (questId: string) => boolean;
  isQuestActive: (questId: string) => boolean;
  isQuestReadyToTurnIn: (questId: string) => boolean;
}

export const useQuestStore = create<QuestStore>((set, get) => ({
  missions: [...DEFAULT_QUESTS],
  activeMissions: [],
  completedMissions: [],
  currentMission: null,
  availableNPCMissions: new Map(),

  initQuests: () => {
    set({ 
      missions: [...DEFAULT_QUESTS],
      activeMissions: [],
      completedMissions: [],
      currentMission: null
    });
  },

  getMissionsForNPC: (npcId: string) => {
    const { missions, availableNPCMissions } = get();
    const missionIds = availableNPCMissions.get(npcId) || [];
    return missions.filter(mission => missionIds.includes(mission.id));
  },

  getQuestById: (questId: string) => {
    const { missions, activeMissions, completedMissions } = get();
    return [...missions, ...activeMissions, ...completedMissions]
      .find(mission => mission.id === questId);
  },

  getQuestStatus: (questId: string) => {
    const { activeMissions, completedMissions } = get();
    
    // Se a missão foi concluída
    if (completedMissions.some(mission => mission.id === questId)) {
      return QuestStatus.COMPLETED;
    }
    
    // Se a missão está ativa
    const activeMission = activeMissions.find(mission => mission.id === questId);
    if (activeMission) {
      // Verificar se todos os objetivos foram concluídos
      const allObjectivesComplete = activeMission.objectives.every(
        obj => obj.current >= obj.required
      );
      
      return allObjectivesComplete 
        ? QuestStatus.READY_TO_TURN_IN 
        : QuestStatus.IN_PROGRESS;
    }
    
    // Se a missão está disponível
    return QuestStatus.AVAILABLE;
  },

  acceptQuest: (questId: string) => {
    const { missions } = get();
    const questToAccept = missions.find(mission => mission.id === questId);
    
    if (questToAccept) {
      // Mover missão para ativas
      set(state => ({
        missions: state.missions.filter(mission => mission.id !== questId),
        activeMissions: [...state.activeMissions, questToAccept]
      }));
    }
  },

  completeQuest: (questId: string) => {
    const { activeMissions } = get();
    const questToComplete = activeMissions.find(mission => mission.id === questId);
    
    if (questToComplete) {
      const allObjectivesComplete = questToComplete.objectives.every(
        obj => obj.current >= obj.required
      );
      
      if (allObjectivesComplete) {
        // Marcar como concluída e mover para missões completadas
        const completedQuest = { ...questToComplete, isCompleted: true };
        set(state => ({
          activeMissions: state.activeMissions.filter(mission => mission.id !== questId),
          completedMissions: [...state.completedMissions, completedQuest]
        }));
        return true;
      }
    }
    return false;
  },

  updateQuestObjective: (
    questId: string, 
    type: QuestType, 
    target: string | CharacterType, 
    amount: number = 1
  ) => {
    const { activeMissions } = get();
    const updatedMissions = activeMissions.map(mission => {
      if (mission.id !== questId) return mission;
      
      // Atualizar os objetivos que correspondem ao tipo e alvo
      const updatedObjectives = mission.objectives.map(objective => {
        if (objective.type === type && objective.target === target) {
          return {
            ...objective,
            current: Math.min(objective.current + amount, objective.required)
          };
        }
        return objective;
      });
      
      return { ...mission, objectives: updatedObjectives };
    });
    
    set({ activeMissions: updatedMissions });
  },

  setCurrentMission: (mission: Quest | null) => {
    set({ currentMission: mission });
  },

  assignMissionToNPC: (npcId: string, missionId: string) => {
    set(state => {
      const currentMissions = state.availableNPCMissions.get(npcId) || [];
      const updatedMissions = new Map(state.availableNPCMissions);
      updatedMissions.set(npcId, [...currentMissions, missionId]);
      return { availableNPCMissions: updatedMissions };
    });
  },

  isQuestCompleted: (questId: string) => {
    const { completedMissions } = get();
    return completedMissions.some(mission => mission.id === questId);
  },

  isQuestActive: (questId: string) => {
    const { activeMissions } = get();
    return activeMissions.some(mission => mission.id === questId);
  },

  isQuestReadyToTurnIn: (questId: string) => {
    const { activeMissions } = get();
    const activeMission = activeMissions.find(mission => mission.id === questId);
    if (activeMission) {
      return activeMission.objectives.every(obj => obj.current >= obj.required);
    }
    return false;
  }
}));