import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';
import { Entity, EntityType, getDirectionVector } from '../../game/entities/Entity';
import { createWandererEnemy, createShooterEnemy, moveEnemyTowardTarget, moveEnemyRandomly } from '../../game/entities/Enemy';
import { createNPC, moveNPCTowardAttacker, moveNPCIdle } from '../../game/entities/NPC';
import { Projectile, createFireball, moveProjectile } from '../../game/entities/Projectile';
import { getRandomWalkablePosition } from '../../game/world/GameMap';
import { createGameMap } from '../../game/world/GameMap';

export type GamePhase = 'initializing' | 'playing' | 'paused' | 'gameOver';

interface GameState {
  gameState: GamePhase;
  enemies: Entity[];
  npcs: Entity[];
  projectiles: Projectile[];
  
  // Initialization
  init: () => void;
  
  // Update functions
  updateGame: (updates: any) => void;
  moveEnemy: (enemy: Entity, targetEntity: Entity, deltaTime: number) => void;
  moveProjectile: (projectile: Projectile, deltaTime: number) => void;
  
  // Entity creation
  createFireballProjectile: (source: Entity) => void;
}

export const useRPGGame = create<GameState>((set, get) => ({
  gameState: 'initializing',
  enemies: [],
  npcs: [],
  projectiles: [],
  
  // Initialize the game
  init: () => {
    // Create game map
    const gameMap = createGameMap(50, 50);
    
    // Create random enemies
    const wandererEnemies: Entity[] = [];
    const shooterEnemies: Entity[] = [];
    
    // Add wanderer enemies
    for (let i = 0; i < 10; i++) {
      const position = getRandomWalkablePosition(gameMap);
      wandererEnemies.push(createWandererEnemy(position.x, position.y));
    }
    
    // Add shooter enemies
    for (let i = 0; i < 5; i++) {
      const position = getRandomWalkablePosition(gameMap);
      shooterEnemies.push(createShooterEnemy(position.x, position.y));
    }
    
    // Create NPCs
    const npcs: Entity[] = [];
    const npcNames = ['Villager', 'Merchant', 'Guard', 'Farmer', 'Wizard'];
    
    for (let i = 0; i < 5; i++) {
      const position = getRandomWalkablePosition(gameMap);
      npcs.push(createNPC(position.x, position.y, npcNames[i]));
    }
    
    // Update the game state
    set({
      gameState: 'playing',
      enemies: [...wandererEnemies, ...shooterEnemies],
      npcs,
      projectiles: []
    });
    
    // Setup periodic shooter enemy attacks
    setInterval(() => {
      const state = get();
      if (state.gameState !== 'playing') return;
      
      // Find shooter enemies
      const shooterEnemies = state.enemies.filter(
        enemy => enemy.active && enemy.type === EntityType.SHOOTER_ENEMY
      );
      
      // Make each shooter try to attack
      shooterEnemies.forEach(shooter => {
        // Get the player from the usePlayer store
        const { player } = require('./usePlayer').usePlayer.getState();
        
        // Check if the shooter is in attack range and not on cooldown
        const distance = Math.sqrt(
          Math.pow(player.x - shooter.x, 2) + 
          Math.pow(player.y - shooter.y, 2)
        );
        
        const canAttack = distance <= (shooter.attackRange || 200);
        const notOnCooldown = (
          !shooter.lastAttackTime || 
          Date.now() - shooter.lastAttackTime >= (shooter.attackCooldown || 2000)
        );
        
        if (canAttack && notOnCooldown && shooter.active) {
          // Update the shooter's last attack time
          set((state) => ({
            enemies: state.enemies.map(enemy => 
              enemy.id === shooter.id 
                ? { ...enemy, lastAttackTime: Date.now() }
                : enemy
            )
          }));
          
          // Create a fireball projectile
          get().createFireballProjectile(shooter);
        }
      });
    }, 500); // Check every half second
  },
  
  // Update game entities
  updateGame: (updates) => {
    set((state) => {
      const updatedState = { ...state };
      
      // Process each update
      Object.entries(updates).forEach(([id, update]) => {
        if (id === 'player') {
          // Player updates are handled in the usePlayer store
          const { updatePlayer } = require('./usePlayer').usePlayer.getState();
          updatePlayer(update as any);
        } else {
          // Find the entity to update
          let entityFound = false;
          
          // Check enemies
          updatedState.enemies = updatedState.enemies.map(enemy => {
            if (enemy.id === id) {
              entityFound = true;
              return update as Entity;
            }
            return enemy;
          });
          
          // Check NPCs if not found
          if (!entityFound) {
            updatedState.npcs = updatedState.npcs.map(npc => {
              if (npc.id === id) {
                entityFound = true;
                return update as Entity;
              }
              return npc;
            });
          }
          
          // Check projectiles if not found
          if (!entityFound) {
            updatedState.projectiles = updatedState.projectiles.map(projectile => {
              if (projectile.id === id) {
                return update as Projectile;
              }
              return projectile;
            });
          }
        }
      });
      
      return updatedState;
    });
  },
  
  // Move enemy based on its type and state
  moveEnemy: (enemy: Entity, targetEntity: Entity, deltaTime: number) => {
    set((state) => {
      let updatedEnemy = { ...enemy };
      
      if (enemy.type === EntityType.WANDERER_ENEMY || enemy.type === EntityType.SHOOTER_ENEMY) {
        // Wanderers move randomly unless provoked
        if (!enemy.isAggressive && !enemy.wasAttacked) {
          updatedEnemy = moveEnemyRandomly(updatedEnemy, deltaTime);
        }
        // Both enemy types move toward the target if aggressive or provoked
        else {
          updatedEnemy = moveEnemyTowardTarget(updatedEnemy, targetEntity, deltaTime);
          
          // Check if in attack range and not on cooldown
          const distance = Math.sqrt(
            Math.pow(targetEntity.x - updatedEnemy.x, 2) + 
            Math.pow(targetEntity.y - updatedEnemy.y, 2)
          );
          
          const inAttackRange = distance <= (updatedEnemy.attackRange || 50);
          const notOnCooldown = (
            !updatedEnemy.lastAttackTime || 
            Date.now() - updatedEnemy.lastAttackTime >= (updatedEnemy.attackCooldown || 1000)
          );
          
          // If in range and not on cooldown, attack
          if (inAttackRange && notOnCooldown) {
            updatedEnemy.isAttacking = true;
            updatedEnemy.lastAttackTime = Date.now();
            
            // Reset attack flag after a short delay
            setTimeout(() => {
              set((state) => ({
                enemies: state.enemies.map(e => 
                  e.id === updatedEnemy.id 
                    ? { ...e, isAttacking: false }
                    : e
                )
              }));
            }, 300);
          } else {
            updatedEnemy.isAttacking = false;
          }
        }
      }
      
      // Update the enemy in the state
      return {
        enemies: state.enemies.map(e => e.id === enemy.id ? updatedEnemy : e)
      };
    });
  },
  
  // Move projectile based on its direction and speed
  moveProjectile: (projectile: Projectile, deltaTime: number) => {
    set((state) => {
      const updatedProjectile = moveProjectile(projectile, deltaTime);
      
      return {
        projectiles: state.projectiles.map(p => 
          p.id === projectile.id ? updatedProjectile : p
        )
      };
    });
  },
  
  // Create a fireball projectile from source entity
  createFireballProjectile: (source: Entity) => {
    set((state) => {
      // If it's the player, get the player's target direction
      let targetX, targetY;
      
      if (source.type === EntityType.PLAYER) {
        // For player, shoot in front of them based on position
        const { player } = require('./usePlayer').usePlayer.getState();
        
        // Create the fireball projectile
        const { x, y } = player;
        
        // Use a default direction (right) or player's last movement direction
        const directionX = 1; // Default to right
        const directionY = 0;
        
        targetX = x + directionX * 100;
        targetY = y + directionY * 100;
      } else {
        // For enemies, shoot at the player
        const { player } = require('./usePlayer').usePlayer.getState();
        targetX = player.x;
        targetY = player.y;
      }
      
      // Create the fireball
      const fireball = createFireball(source, targetX, targetY);
      
      // Consume mana if the source entity has mana
      if (source.type === EntityType.PLAYER && source.mana !== undefined) {
        // Update player's mana in the usePlayer store
        const { updatePlayer } = require('./usePlayer').usePlayer.getState();
        updatePlayer({ 
          mana: Math.max(0, source.mana - 15) 
        });
      }
      
      return {
        projectiles: [...state.projectiles, fireball]
      };
    });
  }
}));
