import { create } from 'zustand';
import { useGameState } from './useGameState';

export interface ChatMessage {
  id: string;
  text: string;
  timestamp: number;
  isSystem?: boolean;
}

interface ChatState {
  messages: ChatMessage[];
  inputValue: string;
  isOpen: boolean;
  addMessage: (text: string, isSystem?: boolean) => void;
  setInputValue: (value: string) => void;
  toggleChat: () => void;
  closeChat: () => void;
  openChat: () => void;
  processCommand: (command: string) => boolean;
  clearMessages: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages: [],
  inputValue: '',
  isOpen: false,
  
  addMessage: (text: string, isSystem = false) => {
    set((state) => ({
      messages: [
        ...state.messages, 
        { 
          id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`, 
          text, 
          timestamp: Date.now(),
          isSystem
        }
      ].slice(-50) // Limita a 50 mensagens
    }));
  },
  
  setInputValue: (value: string) => set({ inputValue: value }),
  
  toggleChat: () => set((state) => ({ isOpen: !state.isOpen })),
  
  closeChat: () => set({ isOpen: false }),
  
  openChat: () => set({ isOpen: true }),
  
  clearMessages: () => set({ messages: [] }),
  
  processCommand: (command: string) => {
    if (!command.startsWith('/')) return false;
    
    const args = command.split(' ');
    const cmd = args[0].toLowerCase();
    const gameState = useGameState.getState();
    const player = gameState.player;
    
    switch (cmd) {
      case '/stats':
        // Formato: /stats [race, class, attribute, tp] [add, remove, set] [valor/nome]
        if (args.length < 3) {
          get().addMessage('Uso: /stats [race, class, attribute, tp] [add, remove, set] [valor]', true);
          get().addMessage('Exemplo: /stats race set saiyan', true);
          get().addMessage('Exemplo: /stats tp add 100', true);
          get().addMessage('Exemplo: /stats strength set 10', true);
          return true;
        }
        
        const target = args[1].toLowerCase();
        const action = args[2].toLowerCase();
        
        // Verificar se a ação é válida
        if (!['add', 'remove', 'set'].includes(action)) {
          get().addMessage('Ação inválida. Use: add, remove ou set', true);
          return true;
        }
        
        // MODIFICAR RAÇA
        if (target === 'race' || target === 'raca') {
          if (action !== 'set') {
            get().addMessage('Para raça, utilize apenas a ação "set"', true);
            return true;
          }
          
          if (args.length < 4) {
            get().addMessage('Uso: /stats race set [human, saiyan, namekian, arcosian]', true);
            return true;
          }
          
          const race = args[3].toLowerCase();
          const validRaces = ['human', 'saiyan', 'namekian', 'arcosian'];
          
          if (!validRaces.includes(race)) {
            get().addMessage(`Raça inválida. Opções: ${validRaces.join(', ')}`, true);
            return true;
          }
          
          // Atualiza a raça do jogador
          gameState.updatePlayer({
            ...player,
            selectedRace: race,
          });
          
          get().addMessage(`Raça alterada para: ${race}`, true);
          return true;
        }
        
        // MODIFICAR CLASSE
        if (target === 'class' || target === 'classe') {
          if (action !== 'set') {
            get().addMessage('Para classe, utilize apenas a ação "set"', true);
            return true;
          }
          
          if (args.length < 4) {
            get().addMessage('Uso: /stats class set [warrior, spiritualist, tanker]', true);
            return true;
          }
          
          const playerClass = args[3].toLowerCase();
          const validClasses = ['warrior', 'spiritualist', 'tanker'];
          const classMappings: Record<string, string> = {
            'warrior': 'warrior',
            'spiritualist': 'spiritualist',
            'tanker': 'tanker'
          };
          
          if (!validClasses.includes(playerClass)) {
            get().addMessage(`Classe inválida. Opções: ${validClasses.join(', ')}`, true);
            return true;
          }
          
          // Mapeia classe em inglês
          const className = classMappings[playerClass] || playerClass;
          
          // Atualiza a classe do jogador
          gameState.updatePlayer({
            ...player,
            selectedClass: className,
          });
          
          const displayName = {
            'warrior': 'Guerreiro',
            'spiritualist': 'Espiritualista', 
            'tanker': 'Tanker'
          }[className] || className;
          
          get().addMessage(`Classe alterada para: ${displayName}`, true);
          return true;
        }
        
        // MODIFICAR TP (TRANSFORMATION POINTS)
        if (target === 'tp') {
          if (args.length < 4 || isNaN(parseInt(args[3]))) {
            get().addMessage(`Uso: /stats tp ${action} [valor]`, true);
            return true;
          }
          
          const value = parseInt(args[3]);
          let newTP = player.stats.transformationPoints;
          
          if (action === 'set') {
            newTP = value;
          } else if (action === 'add') {
            newTP += value;
          } else if (action === 'remove') {
            newTP = Math.max(0, newTP - value);
          }
          
          // Atualiza os pontos de transformação
          gameState.updatePlayer({
            ...player,
            stats: {
              ...player.stats,
              transformationPoints: newTP
            }
          });
          
          get().addMessage(`Pontos de transformação ${action === 'set' ? 'definidos para' : action === 'add' ? 'aumentados para' : 'reduzidos para'}: ${newTP}`, true);
          return true;
        }
        
        // MODIFICAR UM ATRIBUTO ESPECÍFICO
        const validAttributes = ['strength', 'constitution', 'dexterity', 'willpower', 'spirit'];
        if (validAttributes.includes(target)) {
          if (args.length < 4 || isNaN(parseInt(args[3]))) {
            get().addMessage(`Uso: /stats ${target} ${action} [valor]`, true);
            return true;
          }
          
          const value = parseInt(args[3]);
          let newValue = player.stats[target as keyof typeof player.stats] as number;
          
          if (action === 'set') {
            newValue = value;
          } else if (action === 'add') {
            newValue += value;
          } else if (action === 'remove') {
            newValue = Math.max(1, newValue - value); // Não permitir valores menores que 1
          }
          
          // Atualiza o atributo do jogador
          gameState.updatePlayer({
            ...player,
            stats: {
              ...player.stats,
              [target]: newValue
            }
          });
          
          const attrDisplay = {
            'strength': 'força',
            'constitution': 'constituição',
            'dexterity': 'destreza',
            'willpower': 'força de vontade',
            'spirit': 'espírito'
          }[target] || target;
          
          get().addMessage(`Atributo ${attrDisplay} ${action === 'set' ? 'definido para' : action === 'add' ? 'aumentado para' : 'reduzido para'}: ${newValue}`, true);
          return true;
        }
        
        get().addMessage(`Alvo inválido: ${target}. Use: race, class, tp, strength, constitution, dexterity, willpower, spirit`, true);
        return true;
      
      case '/help':
      case '/ajuda':
        get().addMessage('Comandos disponíveis:', true);
        get().addMessage('/stats race set [human, saiyan, namekian, arcosian] - Define a raça', true);
        get().addMessage('/stats class set [warrior, spiritualist, tanker] - Define a classe', true);
        get().addMessage('/stats tp [add|remove|set] [valor] - Modifica pontos de transformação', true);
        get().addMessage('/stats [atributo] [add|remove|set] [valor] - Modifica atributos (strength, constitution, etc)', true);
        get().addMessage('/clear - Limpa o chat', true);
        return true;
        
      case '/clear':
      case '/limpar':
        get().clearMessages();
        get().addMessage('Chat limpo', true);
        return true;
        
      default:
        get().addMessage(`Comando desconhecido: ${cmd}. Digite /help para ver os comandos.`, true);
        return true;
    }
  }
}));