// Game types

export interface Position {
  x: number;
  y: number;
}

export interface Size {
  width: number;
  height: number;
}

export interface Velocity {
  x: number;
  y: number;
}

export interface Stats {
  strength: number;     // Affects attack damage (+2 por ponto)
  constitution: number; // Affects max health (+20 por ponto)
  dexterity: number;    // Affects speed and resistance (+1 velocidade, +1 resistência por ponto)
  willpower: number;    // Affects ki attack power (+2 por ponto)
  spirit: number;       // Affects max ki (+20 por ponto)
}

export interface CharacterStats extends Stats {
  health: number;
  maxHealth: number;
  ki: number;         // Renomeado de mana para ki
  maxKi: number;      // Renomeado de maxMana para maxKi
  stamina: number;
  maxStamina: number;
  experiencePoints: number;
  level: number;
  statPoints: number;
  transformationPoints: number; // TP - Pontos de transformação para comprar upgrades
  transformationLevel: number;  // Nível atual de transformação
  transformationCost: number;   // Custo atual para a próxima transformação
  lastDamageTime: number;       // Último momento em que recebeu dano
  lastAttackTime: number;       // Último momento em que atacou
  resistance: number;           // Resistência a dano
}

export enum CharacterType {
  PLAYER = 'player',
  PASSIVE_ENEMY = 'passive_enemy',
  AGGRESSIVE_ENEMY = 'aggressive_enemy',
  NPC = 'npc'
}

export interface Character {
  id: string;
  position: Position;
  size: Size;
  velocity: Velocity;
  stats: CharacterStats;
  type: CharacterType;
  color: string;
  isAttacking: boolean;
  attackCooldown: number;
  isProvoked: boolean;  // For passive enemies and NPCs
  lastAttackTime: number;
  lastDamageTime: number; // Adicionado para corrigir o erro
  createdAt: number;      // Timestamp de criação para controlar tempo de vida
  // Propriedades adicionais para a mecânica de raça e jogador
  name?: string;         // Nome do jogador
  selectedRace?: string;  // Raça selecionada pelo jogador
  selectedClass?: string; // Classe selecionada pelo jogador
  speed?: number;        // Velocidade de movimento
  damage?: number;       // Dano de ataque físico
  kiDamage?: number;     // Dano de ataque de KI
  resistance?: number;   // Resistência a dano
  // Propriedades para NPCs de missão
  hasMission?: boolean;  // Se o NPC tem uma missão para oferecer
  missionId?: string;    // ID da missão que o NPC oferece
}

export interface Projectile {
  id: string;
  position: Position;
  velocity: Velocity;
  size: Size;
  damage: number;
  ownerId: string;
  color: string;
}

// Interface para textos flutuantes de dano/cura/ki/stamina
export interface DamageText {
  id: string;
  position: Position;
  value: number;
  color: string;
  createdAt: number;
  type: 'damage' | 'heal' | 'ki' | 'stamina'; // Tipo de texto (dano, cura, etc)
  velocity: Velocity; // Para movimento leve do texto
}

// Enum para tipos de missões
export enum QuestType {
  KILL_ENEMIES = 'kill_enemies',
  COLLECT_ITEMS = 'collect_items',
  TALK_TO_NPC = 'talk_to_npc',
  REACH_LEVEL = 'reach_level',
  REACH_TRANSFORMATION = 'reach_transformation'
}

// Interface para objetivo de missão
export interface QuestObjective {
  type: QuestType;
  target: string | CharacterType; // Tipo de inimigo, nome do NPC, etc.
  required: number;
  current: number;
}

// Interface para recompensa de missão
export interface QuestReward {
  tp: number;           // Pontos de transformação
  experience?: number;  // Experiência
  items?: string[];     // Itens (para implementação futura)
}

// Interface para missões
export interface Quest {
  id: string;
  title: string;
  description: string;
  objectives: QuestObjective[];
  rewards: QuestReward;
  isCompleted: boolean;
  npcId?: string;       // ID do NPC que deu a missão
}

// Para status de missão visual (ícone)
export enum QuestStatus {
  AVAILABLE = 'available',     // Missão disponível
  IN_PROGRESS = 'in_progress', // Missão em andamento
  COMPLETED = 'completed',     // Missão concluída
  READY_TO_TURN_IN = 'ready_to_turn_in' // Missão pronta para entregar
}

// Interface para jogador online
export interface OnlinePlayer {
  id: string;
  name: string;
  position: Position;
  race: string;
  playerClass: string; // Adicionando classe do jogador
  color: string;
  transformationLevel: number;
  isAttacking: boolean;
}

export interface GameState {
  player: Character;
  enemies: Character[];
  npcs: Character[];
  projectiles: Projectile[];
  isGameRunning: boolean;
  isUpgradeMenuOpen: boolean;
  isGameOver: boolean;
  isRaceSelectionOpen: boolean;
  isTransformationMenuOpen: boolean;
  isTechniquesMenuOpen: boolean;
  isDialogueOpen: boolean;      // Caixa de diálogo aberta
  isMissionMenuOpen: boolean;   // Menu de missões aberto
  currentDialogue?: string;     // Texto atual do diálogo
  currentNPC?: Character;       // NPC com quem está falando
  currentMission?: Quest;       // Missão atual em diálogo
  selectedRace: string | null;
  playerName: string | null;    // Nome do jogador
  temporaryDamageTexts: DamageText[]; // Textos temporários de dano/cura
  missions: Quest[];            // Lista de missões disponíveis
  activeMissions: Quest[];      // Missões ativas do jogador
  completedMissions: Quest[];   // Missões completadas
  onlinePlayers: OnlinePlayer[]; // Jogadores online
  kills: number;
  timeElapsed: number;
}

export interface Controls {
  up: boolean;
  down: boolean;
  left: boolean;
  right: boolean;
  attack: boolean;
  magic: boolean;
  transform: boolean; // Controle para transformação
}
