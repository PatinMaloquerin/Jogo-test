import { Position, Size, Character, Projectile } from '../types';

// Check if two rectangles overlap (Axis-Aligned Bounding Box collision)
export function checkCollision(
  pos1: Position,
  size1: Size,
  pos2: Position,
  size2: Size
): boolean {
  return (
    pos1.x < pos2.x + size2.width &&
    pos1.x + size1.width > pos2.x &&
    pos1.y < pos2.y + size2.height &&
    pos1.y + size1.height > pos2.y
  );
}

// Check if a character collides with any other character
export function checkCharacterCollisions(
  character: Character,
  others: Character[]
): Character | null {
  for (const other of others) {
    if (other.id !== character.id) {
      if (
        checkCollision(
          character.position,
          character.size,
          other.position,
          other.size
        )
      ) {
        return other;
      }
    }
  }
  return null;
}

// Check if a projectile hits a character
export function checkProjectileCollision(
  projectile: Projectile,
  characters: Character[]
): Character | null {
  for (const character of characters) {
    // Make sure projectiles don't hit their owner
    if (character.id !== projectile.ownerId) {
      if (
        checkCollision(
          projectile.position,
          projectile.size,
          character.position,
          character.size
        )
      ) {
        return character;
      }
    }
  }
  return null;
}

// Check if position is within game boundaries
export function isInBounds(position: Position, size: Size, canvasWidth: number, canvasHeight: number): boolean {
  return (
    position.x >= 0 &&
    position.x + size.width <= canvasWidth &&
    position.y >= 0 &&
    position.y + size.height <= canvasHeight
  );
}

// Calculate new position after resolving collision
export function resolveCollision(
  currentPos: Position,
  size: Size,
  velocity: { x: number; y: number },
  obstacles: Character[]
): Position {
  // First try moving only along the X axis
  const newPosX = {
    x: currentPos.x + velocity.x,
    y: currentPos.y
  };
  
  // Check if this new X position collides with any obstacle
  const xCollision = obstacles.some(obstacle => 
    obstacle.id !== 'player' && // Don't check collision with self if player
    checkCollision(
      newPosX,
      size,
      obstacle.position,
      obstacle.size
    )
  );
  
  // Now try moving only along the Y axis
  const newPosY = {
    x: currentPos.x,
    y: currentPos.y + velocity.y
  };
  
  // Check if this new Y position collides with any obstacle
  const yCollision = obstacles.some(obstacle => 
    obstacle.id !== 'player' && // Don't check collision with self if player
    checkCollision(
      newPosY,
      size,
      obstacle.position,
      obstacle.size
    )
  );
  
  // Return new position based on collision results
  return {
    x: xCollision ? currentPos.x : newPosX.x,
    y: yCollision ? currentPos.y : newPosY.y
  };
}
