import { CharacterStats, CharacterType, Position, Size, Character, Projectile, DamageText } from '../types';

// Generate a unique ID
export function generateId(): string {
  return Math.random().toString(36).substring(2, 9);
}

// Calculate damage based on attacker and defender stats
export function calculateDamage(attacker: Character, defender: Character): number {
  // Physical attack formula
  if (attacker.isAttacking) {
    // Base damage + strength bonus
    const baseDamage = 5;
    const strengthBonus = attacker.stats.strength * 2;
    const defenseReduction = defender.stats.constitution * 0.5;
    
    return Math.max(1, Math.floor(baseDamage + strengthBonus - defenseReduction));
  }
  
  return 0;
}

// Calculate ki attack damage based on willpower (and transformation)
export function calculateKiDamage(attacker: Character): number {
  const baseDamage = 5;
  const willpowerBonus = attacker.stats.willpower * 2; // +2 por ponto
  const transformationMultiplier = getTransformationMultiplier(attacker.stats.transformationLevel);
  
  return Math.floor((baseDamage + willpowerBonus) * transformationMultiplier);
}

// Get transformation multiplier based on level
export function getTransformationMultiplier(level: number): number {
  switch (level) {
    case 1: return 1.25; // 1st transformation (25% boost)
    case 2: return 1.5;  // 2nd transformation (50% boost)
    case 3: return 2.0;  // 3rd transformation (100% boost)
    case 4: return 3.0;  // 4th transformation (200% boost)
    case 5: return 5.0;  // 5th transformation (400% boost)
    default: return 1.0; // Base form (no boost)
  }
}

// Apply transformation
export function applyTransformation(character: Character): Character {
  const updatedCharacter = { ...character };
  
  // Implementar a "Superform" - Uma transformação direta para o nível máximo
  // Se for a primeira transformação e tiver 500+ pontos, ativar a Superform
  if (character.stats.transformationLevel === 0 && character.stats.transformationPoints >= 500) {
    // Se jogador tem 500+ TP, transformar direto para o nível 5 (Superform)
    updatedCharacter.stats.transformationLevel = 5; // Nível máximo
    updatedCharacter.stats.transformationPoints -= 500; // Custo da Superform
    
    // Apply stat multipliers based on maximum transformation level
    const multiplier = getTransformationMultiplier(5); // Nível 5 = multiplicador 5.0
    
    // Apply multiplier to all base stats
    updatedCharacter.stats.strength = Math.floor(character.stats.strength * multiplier);
    updatedCharacter.stats.constitution = Math.floor(character.stats.constitution * multiplier);
    updatedCharacter.stats.dexterity = Math.floor(character.stats.dexterity * multiplier);
    updatedCharacter.stats.willpower = Math.floor(character.stats.willpower * multiplier);
    updatedCharacter.stats.spirit = Math.floor(character.stats.spirit * multiplier);
    
    // Recalcular stats derivados com bônus especiais para Superform
    updatedCharacter.stats.maxHealth = updatedCharacter.stats.constitution * 20; // Exatamente 20×CON
    updatedCharacter.stats.health = updatedCharacter.stats.maxHealth; // Recupera vida ao transformar
    updatedCharacter.stats.maxKi = updatedCharacter.stats.spirit * 20; // Exatamente 20×SPI
    updatedCharacter.stats.ki = updatedCharacter.stats.maxKi; // Recupera ki ao transformar
    updatedCharacter.stats.maxStamina = 100 + (updatedCharacter.stats.dexterity * 10); // +10 por ponto em Superform
    updatedCharacter.stats.stamina = updatedCharacter.stats.maxStamina; // Recupera stamina ao transformar
    
    // Cor especial para a Superform
    updatedCharacter.color = '#00FFFF'; // Ciano brilhante para a Superform
    
    return updatedCharacter;
  }
  
  // Transformação normal (progressiva)
  // Check if character has enough transformation points
  const transformationCost = character.stats.transformationCost;
  if (character.stats.transformationPoints < transformationCost) {
    return character; // Not enough points
  }
  
  // Check for maximum transformation level (5)
  if (character.stats.transformationLevel >= 5) {
    return character; // Already at max level
  }
  
  // Apply transformation
  updatedCharacter.stats.transformationLevel += 1;
  updatedCharacter.stats.transformationPoints -= transformationCost;
  
  // Increase cost for next transformation (each level costs +100 TP)
  updatedCharacter.stats.transformationCost += 100;
  
  // Apply stat multipliers based on new transformation level
  const multiplier = getTransformationMultiplier(updatedCharacter.stats.transformationLevel);
  
  // Apply multiplier to all base stats
  updatedCharacter.stats.strength = Math.floor(character.stats.strength * multiplier);
  updatedCharacter.stats.constitution = Math.floor(character.stats.constitution * multiplier);
  updatedCharacter.stats.dexterity = Math.floor(character.stats.dexterity * multiplier);
  updatedCharacter.stats.willpower = Math.floor(character.stats.willpower * multiplier);
  updatedCharacter.stats.spirit = Math.floor(character.stats.spirit * multiplier);
  
  // Recalcular stats derivados
  updatedCharacter.stats.maxHealth = updatedCharacter.stats.constitution * 20; // Exatamente 20×CON
  updatedCharacter.stats.health = updatedCharacter.stats.maxHealth; // Recupera vida ao transformar
  updatedCharacter.stats.maxKi = updatedCharacter.stats.spirit * 20; // Exatamente 20×SPI
  updatedCharacter.stats.ki = updatedCharacter.stats.maxKi; // Recupera ki ao transformar
  updatedCharacter.stats.maxStamina = 100 + (updatedCharacter.stats.dexterity * 5);
  updatedCharacter.stats.stamina = updatedCharacter.stats.maxStamina; // Recupera stamina ao transformar
  
  // Altera a cor do personagem para indicar a transformação
  switch(updatedCharacter.stats.transformationLevel) {
    case 1:
      updatedCharacter.color = '#FFD700'; // Dourado
      break;
    case 2:
      updatedCharacter.color = '#FF4500'; // Vermelho-alaranjado
      break;
    case 3:
      updatedCharacter.color = '#4169E1'; // Azul
      break;
    case 4:
      updatedCharacter.color = '#9932CC'; // Roxo
      break;
    case 5:
      updatedCharacter.color = '#FFFFFF'; // Branco brilhante
      break;
  }
  
  return updatedCharacter;
}

// Calculate movement speed based on dexterity
export function calculateMovementSpeed(character: Character): number {
  const baseSpeed = 2;
  const dexterityBonus = character.stats.dexterity * 0.1;
  
  return baseSpeed + dexterityBonus;
}

// Apply damage to a character and return if they died
export function applyDamage(character: Character, damage: number): boolean {
  character.stats.health -= damage;
  
  // Check if character died
  if (character.stats.health <= 0) {
    character.stats.health = 0;
    return true; // Character died
  }
  
  return false; // Character survived
}

// Create a new character with default stats
export function createCharacter(
  type: CharacterType, 
  position: Position, 
  color: string,
  size: Size = { width: 30, height: 30 }
): Character {
  const baseStats: CharacterStats = {
    // Atributos base
    strength: 1,
    constitution: 1,
    dexterity: 1,
    willpower: 1,
    spirit: 1,
    
    // Recursos
    health: 20,        // Valor inicial = 20×CON (con = 1)
    maxHealth: 20,     // Valor inicial = 20×CON (con = 1)
    ki: 20,            // Valor inicial = 20×SPI (spi = 1)
    maxKi: 20,         // Valor inicial = 20×SPI (spi = 1)
    stamina: 100,
    maxStamina: 100,
    
    // Progressão
    experiencePoints: 0,
    level: 1,
    statPoints: 0,
    
    // Sistema de transformação
    transformationPoints: 0,
    transformationLevel: 0,
    transformationCost: 100,  // Custo inicial de 100 TP
    
    // Tempos
    lastDamageTime: 0,
    lastAttackTime: 0,
    
    // Resistência
    resistance: 0
  };
  
  // Adjust stats based on character type
  switch (type) {
    case CharacterType.PLAYER:
      baseStats.statPoints = 5; // Start with some stat points
      baseStats.maxStamina = 100;
      baseStats.stamina = 100;
      break;
    case CharacterType.PASSIVE_ENEMY:
      baseStats.strength = 2;
      baseStats.constitution = 2;
      baseStats.health = baseStats.constitution * 20;
      baseStats.maxHealth = baseStats.health;
      break;
    case CharacterType.AGGRESSIVE_ENEMY:
      baseStats.willpower = 3;
      baseStats.constitution = 2;
      baseStats.spirit = 2;
      baseStats.health = baseStats.constitution * 20;
      baseStats.maxHealth = baseStats.health;
      baseStats.ki = baseStats.spirit * 20;
      baseStats.maxKi = baseStats.ki;
      break;
    case CharacterType.NPC:
      baseStats.constitution = 2;
      baseStats.health = baseStats.constitution * 20;
      baseStats.maxHealth = baseStats.health;
      break;
  }
  
  return {
    id: generateId(),
    position,
    size,
    velocity: { x: 0, y: 0 },
    stats: baseStats,
    type,
    color,
    isAttacking: false,
    attackCooldown: 0,
    isProvoked: false,
    lastAttackTime: 0,
    lastDamageTime: 0,
    createdAt: Date.now() // Adiciona timestamp de criação para controle de tempo de vida
  };
}

// Create a projectile (fireball, magic attack, etc.)
export function createProjectile(
  ownerId: string,
  position: Position,
  direction: { x: number, y: number },
  damage: number,
  color: string = 'orange'
): Projectile {
  // Normalize direction vector
  const magnitude = Math.sqrt(direction.x * direction.x + direction.y * direction.y);
  
  // Handle the case where magnitude is 0 (no direction)
  const normalizedDirection = magnitude === 0 
    ? { x: 0, y: 0 } 
    : { x: direction.x / magnitude, y: direction.y / magnitude };
  
  // Set speed for the projectile
  const speed = 5;
  
  return {
    id: generateId(),
    position: { ...position },
    velocity: {
      x: normalizedDirection.x * speed,
      y: normalizedDirection.y * speed
    },
    size: { width: 10, height: 10 },
    damage,
    ownerId,
    color
  };
}

// Check if enough time has passed since the last attack (for cooldown)
export function canAttack(character: Character, cooldownMs: number): boolean {
  const currentTime = Date.now();
  return currentTime - character.lastAttackTime >= cooldownMs;
}

// Update character stats based on level up
export function applyStatUpgrade(character: Character, statName: keyof CharacterStats): Character {
  if (character.stats.statPoints <= 0) {
    return character;
  }
  
  const updatedCharacter = { ...character };
  
  // Increase the specified stat
  updatedCharacter.stats[statName] += 1;
  updatedCharacter.stats.statPoints -= 1;
  
  // Update derived stats
  switch (statName) {
    case 'constitution':
      updatedCharacter.stats.maxHealth = updatedCharacter.stats.constitution * 20; // Exatamente 20×CON
      updatedCharacter.stats.health = updatedCharacter.stats.maxHealth;
      break;
    case 'spirit':
      updatedCharacter.stats.maxKi = updatedCharacter.stats.spirit * 20; // Exatamente 20×SPI
      updatedCharacter.stats.ki = updatedCharacter.stats.maxKi;
      break;
    case 'dexterity':
      updatedCharacter.stats.maxStamina = 100 + (updatedCharacter.stats.dexterity * 5);
      updatedCharacter.stats.stamina = updatedCharacter.stats.maxStamina;
      updatedCharacter.stats.resistance = updatedCharacter.stats.dexterity; // +1 resistência por ponto
      break;
    case 'strength':
      // Sem efeito direto, mas aumenta o dano em +2 por ponto na função calculateDamage
      break;
    case 'willpower':
      // Sem efeito direto, mas aumenta o dano de ki em +2 por ponto na função calculateKiDamage
      break;
  }
  
  return updatedCharacter;
}

// Award experience points and check for level up
export function awardExperience(character: Character, amount: number): Character {
  const updatedCharacter = { ...character };
  updatedCharacter.stats.experiencePoints += amount;
  
  // Check for level up (simple formula: 100 * current level)
  const experienceNeeded = 100 * updatedCharacter.stats.level;
  
  if (updatedCharacter.stats.experiencePoints >= experienceNeeded) {
    updatedCharacter.stats.experiencePoints -= experienceNeeded;
    updatedCharacter.stats.level += 1;
    updatedCharacter.stats.statPoints += 5; // Award stat points on level up
    
    // Recover health, ki, stamina on level up
    updatedCharacter.stats.health = updatedCharacter.stats.maxHealth;
    updatedCharacter.stats.ki = updatedCharacter.stats.maxKi;
    updatedCharacter.stats.stamina = updatedCharacter.stats.maxStamina;
    
    // Award transformation points
    updatedCharacter.stats.transformationPoints += 20; // 20 TP por level
  }
  
  return updatedCharacter;
}

// Create a floating damage text
export function createDamageText(
  position: Position, 
  value: number, 
  type: 'damage' | 'heal' | 'ki' | 'stamina' = 'damage'
): DamageText {
  const colors = {
    damage: 'red',
    heal: 'green',
    ki: 'blue',
    stamina: 'yellow'
  };
  
  return {
    id: generateId(),
    position: { x: position.x, y: position.y - 20 }, // Appear above the entity
    value: Math.floor(value),
    color: colors[type],
    createdAt: Date.now(),
    type,
    velocity: { x: (Math.random() - 0.5) * 0.5, y: -0.7 } // Float upward with slight random horizontal drift
  };
}

// Regenerate health if not damaged recently
export function checkHealthRegeneration(character: Character): { character: Character, regenerated: number } {
  const updatedCharacter = { ...character };
  const currentTime = Date.now();
  const healthRegenerationDelay = 5000; // 5 seconds after last damage
  
  // Check if enough time has passed since last damage
  if (currentTime - updatedCharacter.stats.lastDamageTime < healthRegenerationDelay) {
    return { character: updatedCharacter, regenerated: 0 };
  }
  
  // Generate random health regeneration (1-5 points)
  const regenAmount = Math.floor(Math.random() * 5) + 1;
  
  // Apply regeneration (up to maxHealth)
  if (updatedCharacter.stats.health < updatedCharacter.stats.maxHealth) {
    updatedCharacter.stats.health = Math.min(
      updatedCharacter.stats.health + regenAmount,
      updatedCharacter.stats.maxHealth
    );
    return { character: updatedCharacter, regenerated: regenAmount };
  }
  
  return { character: updatedCharacter, regenerated: 0 };
}

// Handle transformation ki drain
export function handleTransformationKiDrain(character: Character, deltaTime: number): Character {
  const updatedCharacter = { ...character };
  
  // If not transformed, no ki drain
  if (updatedCharacter.stats.transformationLevel === 0) {
    return updatedCharacter;
  }
  
  // Calculate ki drain based on transformation level
  // Level 1: -1 per second, Level 2: -2 per second, etc.
  const kiDrainPerSecond = updatedCharacter.stats.transformationLevel;
  const kiDrainAmount = kiDrainPerSecond * (deltaTime / 1000); // Convert from ms to seconds
  
  // Apply ki drain
  updatedCharacter.stats.ki = Math.max(0, updatedCharacter.stats.ki - kiDrainAmount);
  
  // If ki reaches 0, revert to base form
  if (updatedCharacter.stats.ki <= 0) {
    updatedCharacter.stats.transformationLevel = 0;
    updatedCharacter.stats.ki = 0;
  }
  
  return updatedCharacter;
}
