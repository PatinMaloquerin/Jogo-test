import { CharacterType } from "../types";

export enum QuestType {
  KILL_ENEMIES = 'kill_enemies',
  COLLECT_ITEMS = 'collect_items',
  TALK_TO_NPC = 'talk_to_npc'
}

export enum QuestStatus {
  NOT_STARTED = 'not_started',
  IN_PROGRESS = 'in_progress',
  COMPLETED = 'completed',
  FAILED = 'failed'
}

export interface QuestObjective {
  type: QuestType;
  targetId?: string;
  targetType?: CharacterType;
  targetCount: number;
  currentCount: number;
  description: string;
}

export interface QuestReward {
  experiencePoints: number;
  transformationPoints?: number;
  statPoints?: number;
}

export interface Quest {
  id: string;
  title: string;
  description: string;
  giver: string; // NPC ID que dá a quest
  status: QuestStatus;
  objectives: QuestObjective[];
  rewards: QuestReward;
  nextQuestId?: string; // Para criar cadeias de quests
  requiredLevel?: number;
}

export interface DialogueOption {
  text: string;
  nextId?: string; // ID do próximo diálogo
  questAction?: {
    type: 'start' | 'complete';
    questId: string;
  };
  condition?: {
    type: 'quest_status' | 'player_level';
    questId?: string;
    status?: QuestStatus;
    level?: number;
  };
}

export interface DialogueNode {
  id: string;
  npcId: string;
  text: string;
  options: DialogueOption[];
}